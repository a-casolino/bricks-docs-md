# Bricks Data Model

Source: https://academy.bricksbuilder.io/developer/schema/

*How Bricks stores and structures data: elements, content areas, page/template settings, and global data structures.*

This page explains how Bricks structures its data. Use it alongside the individual element and control schemas to understand or generate valid Bricks content. Each JSON file describes the exact shape of data Bricks reads and writes, so AI coding assistants, build tools, import/export scripts, and custom integrations can generate, validate, or transform Bricks content without the builder UI.

**Schema version:** 2.5-beta2

## Element structure

Every element in Bricks shares the same envelope, regardless of its type:

```json
{
  "id": "dlceeu",
  "name": "button",
  "parent": 0,
  "children": [],
  "settings": { "text": "I am a button", "style": "primary" },
  "label": "My Button"
}
```

The element envelope has 8 fields (`id`, `name`, `parent`, `children`, `settings`, `selectors`, `label`, `themeStyles`). The `settings` object combines three layers: element-specific controls, inherited CSS controls (the `_`-prefixed keys), and meta-settings (`_cssGlobalClasses`, `_conditions`, `_interactions`, `_attributes`, etc.).

See the [Element schema](./elements/common/element/) for the full envelope reference, settings layers, meta-settings, and selectors documentation.

## Content areas

A Bricks page (or any post type using Bricks) stores its elements across three independent content areas: header, content, and footer. Each content area is a flat array of elements with parent-child references (not a nested tree). An array may contain both regular elements and component instances (identifiable by the presence of a `cid` field).

| Content area | WordPress post meta key | Description |
|---|---|---|
| Header | `_bricks_page_header_2` | Header template elements |
| Content | `_bricks_page_content_2` | Main page/post content |
| Footer | `_bricks_page_footer_2` | Footer template elements |

All three content areas use the exact same data structure: an array of elements as described in the [Element schema](./elements/common/element/).

**Storage:** These are stored as serialized arrays in the `wp_postmeta` table.

| Data | Meta key | PHP constant |
|---|---|---|
| Header elements | `_bricks_page_header_2` | `BRICKS_DB_PAGE_HEADER` |
| Content elements | `_bricks_page_content_2` | `BRICKS_DB_PAGE_CONTENT` |
| Footer elements | `_bricks_page_footer_2` | `BRICKS_DB_PAGE_FOOTER` |

See the [Content Area schema](./general/content-area/) for the array structure and storage details.

### Responsive and state variants

CSS-related settings support breakpoint and pseudo-class suffixes using colon syntax. A setting key with no suffix applies at the base breakpoint (desktop by default):

```
_typography                          → base breakpoint (no suffix)
_typography:tablet_portrait          → tablet portrait breakpoint
_typography:mobile_landscape:hover   → mobile landscape + hover state
```

## Page settings

Per-page configuration controlling header/footer visibility, scroll behavior, SEO metadata, social sharing, and custom code injection. These settings apply to the specific post being edited and are separate from element settings and global data.

```json
{
  "headerDisabled": true,
  "scrollSnapType": "y proximity"
}
```

See the [page settings schema](./settings/page/) for all available controls.

**Storage:** Stored as a serialized array in the `wp_postmeta` table.

| Data | Meta key | PHP constant |
|---|---|---|
| Page settings | `_bricks_page_settings` | `BRICKS_DB_PAGE_SETTINGS` |

## Template settings

Settings specific to Bricks templates (stored as the `bricks_template` custom post type). Includes template conditions that determine where on the site a template is applied (e.g., entire website, specific post types, archives, or individual pages). Header templates also store layout settings such as sticky behavior here.

```json
{
  "templateConditions": [
    { "id": "iwjjdg", "main": "any" }
  ]
}
```

See the [template settings schema](./settings/template/) for all available controls.

**Storage:** Stored as serialized arrays in the `wp_postmeta` table.

| Data | Meta key | PHP constant |
|---|---|---|
| Template settings | `_bricks_template_settings` | `BRICKS_DB_TEMPLATE_SETTINGS` |
| Template type | `_bricks_template_type` | `BRICKS_DB_TEMPLATE_TYPE` |

## Global data structures

Bricks stores several global data structures as WordPress options. These are site-wide and shared across all pages and templates.

**Storage:** All global data is stored as serialized arrays in the `wp_options` table.

| Data | Option name | PHP constant |
|---|---|---|
| Global classes | `bricks_global_classes` | `BRICKS_DB_GLOBAL_CLASSES` |
| Global variables | `bricks_global_variables` | `BRICKS_DB_GLOBAL_VARIABLES` |
| Theme styles | `bricks_theme_styles` | `BRICKS_DB_THEME_STYLES` |
| Color palettes | `bricks_color_palette` | `BRICKS_DB_COLOR_PALETTE` |
| Breakpoints | `bricks_breakpoints` | `BRICKS_DB_BREAKPOINTS` |
| Components | `bricks_components` | `BRICKS_DB_COMPONENTS` |
| Pseudo-classes | `bricks_pseudo_classes` | `BRICKS_DB_PSEUDO_CLASSES` |

### Global classes

Reusable CSS class definitions that can be applied to any element via the `_cssGlobalClasses` setting. Edit a class once and every element using it updates everywhere. The `settings` object on a class follows the same structure as element settings, including support for breakpoint and pseudo-class variants using the colon syntax (e.g., `_typography:tablet_portrait`).

```json
[
  {
    "id": "xkatss",
    "name": "hero-section",
    "settings": {
      "_background": {
        "color": {
          "light": "#81D4FA",
          "raw": "var(--bricks-color-sky-blue)",
          "id": "573827"
        }
      },
      "_padding:mobile_portrait": {
        "top": "40",
        "bottom": "40"
      }
    },
    "modified": 1772645626,
    "user_id": 2
  }
]
```

See the [global classes schema](./global/global-classes/).

### Global variables

CSS custom properties that become available site-wide as `var(--variable-name)`. Used to define design tokens (colors, spacing, font sizes, etc.) that can be referenced from any element setting that accepts a CSS value.

```json
[
  { "id": "jeeawn", "name": "primary-color", "value": "green" },
  { "id": "ab3kxz", "name": "spacing-xl", "value": "80px" }
]
```

See the [global variables schema](./global/global-variables/).

### Theme styles

Site-wide default styling applied per element type (e.g., default section padding, heading typography, button colors). Each theme style requires conditions to determine which pages it applies to. Multiple theme styles can coexist with different conditions; a loading method setting controls whether only the most specific or all matching theme styles are applied on a given page.

```json
{
  "my-theme-style": {
    "label": "My Theme Style",
    "settings": {
      "conditions": {
        "conditions": [
          { "id": "vrniaa", "main": "any" }
        ]
      },
      "section": {
        "padding": { "top": "80", "right": "16", "left": "16", "bottom": "80" },
        "_rowGap": "32"
      },
      "heading": {
        "_typography": { "font-family": "Inter", "font-weight": "700" }
      }
    }
  }
}
```

See the [theme styles schema](./global/theme-styles/).

### Color palettes

Named color collections used across the builder. Multiple palettes can coexist. Each color stores a CSS variable reference (`raw`), the resolved light-mode value (`light`), and an optional dark-mode value (`dark`). The `raw` value is what gets written into settings; `light`/`dark` are the resolved display values.

```json
[
  {
    "id": "58e6a6",
    "name": "Brand Colors",
    "colors": [
      { "id": "920e35", "raw": "var(--bricks-color-red)", "light": "#f44336" },
      { "id": "58c724", "raw": "var(--bricks-color-blue)", "light": "#2196f3" },
      { "id": "3f6995", "raw": "var(--bricks-color-green)", "light": "#4caf50" }
    ]
  }
]
```

See the [color palettes schema](./global/color-palettes/).

### Breakpoints

Responsive breakpoint definitions. The entry marked `"base": true` is the default breakpoint; settings with no breakpoint suffix apply at this breakpoint (e.g., `_typography`). All other breakpoints generate a media query at their `width` value and are referenced via colon suffix on the setting key (e.g., `_typography:tablet_portrait`). Users can add custom breakpoints and modify widths.

```json
[
  { "base": true, "key": "desktop", "label": "Desktop", "width": 1279, "icon": "laptop" },
  { "key": "tablet_portrait", "label": "Tablet portrait", "width": 991, "icon": "tablet-portrait" },
  { "key": "mobile_landscape", "label": "Mobile landscape", "width": 767, "icon": "phone-landscape" },
  { "key": "mobile_portrait", "label": "Mobile portrait", "width": 478, "icon": "phone-portrait" }
]
```

See the [breakpoints schema](./global/breakpoints/).

### Components

Reusable element bundles, analogous to components in Vue or React. A component definition holds a tree of elements (`elements`) and an optional list of `properties` that expose specific controls for per-instance customization (e.g., a different heading text or image on each instance). When added to a page, a component instance is created that references the main component via `cid`.

```json
[
  {
    "id": "fdqkmn",
    "category": "Marketing",
    "desc": "A reusable CTA button with configurable label",
    "elements": [
      {
        "id": "fdqkmn",
        "name": "button",
        "parent": 0,
        "children": [],
        "settings": { "text": "Get started", "style": "dark" },
        "label": "CTA Button"
      }
    ],
    "properties": [
      {
        "id": "pbutxt",
        "label": "Button text",
        "type": "text",
        "connections": { "fdqkmn": ["text"] }
      }
    ],
    "_created": 1772645617,
    "_user_id": 2,
    "_version": "2.2-rc2"
  }
]
```

See the [components schema](./global/components/).

### Pseudo-classes

CSS pseudo-classes available in the builder for state variants (e.g., hover, active, focus). These determine which pseudo-class suffixes can be applied to CSS settings using the colon syntax (e.g., `_typography:mobile_portrait:hover`). The defaults are `:hover`, `:active`, and `:focus`, but users can add custom pseudo-classes via Bricks settings.

```json
[":hover", ":active", ":focus"]
```

See the [pseudo-classes schema](./global/pseudo-classes/).

## Nesting example

Below is a real-world hero section showing how elements nest via the flat array structure. The tree view shows the visual hierarchy, followed by the actual data.

```
section (Hero Section 06)
  └─ container
       ├─ block (Content Wrapper)
       │    ├─ heading (h1)
       │    ├─ text-basic (Tagline)
       │    ├─ text-basic (Lede)
       │    └─ div (Button Group)
       │         ├─ button
       │         └─ button (outline)
       └─ block (Media Wrapper)
            └─ image (eager, figure)
```

```json
[
  {
    "id": "13877b",
    "name": "section",
    "parent": 0,
    "children": ["65f029"],
    "settings": { "_cssGlobalClasses": ["skznjf"] },
    "label": "Hero Section 06"
  },
  {
    "id": "65f029",
    "name": "container",
    "parent": "13877b",
    "children": ["bf5a3e", "19454c"],
    "settings": { "_cssGlobalClasses": ["ubprdn"] }
  },
  {
    "id": "bf5a3e",
    "name": "block",
    "parent": "65f029",
    "children": ["c85e7f", "dfe903", "436fc0", "9b4d18"],
    "settings": { "_cssGlobalClasses": ["ebvzqj"] },
    "label": "Content Wrapper"
  },
  {
    "id": "c85e7f",
    "name": "heading",
    "parent": "bf5a3e",
    "children": [],
    "settings": {
      "text": "This hero headline is a temporary placeholder",
      "_cssGlobalClasses": ["deprgo"],
      "tag": "h1",
      "type": "hero"
    }
  },
  {
    "id": "dfe903",
    "name": "text-basic",
    "parent": "bf5a3e",
    "children": [],
    "settings": {
      "text": "Tagline",
      "tag": "p",
      "_cssGlobalClasses": ["dzwkrp", "xlqxzg"]
    },
    "label": "Tagline"
  },
  {
    "id": "436fc0",
    "name": "text-basic",
    "parent": "bf5a3e",
    "children": [],
    "settings": {
      "text": "While we're still finalizing our content, we've included this placeholder text to occupy the space temporarily.",
      "tag": "p",
      "_cssGlobalClasses": ["vpsyry", "ebhacb"]
    },
    "label": "Lede"
  },
  {
    "id": "9b4d18",
    "name": "div",
    "parent": "bf5a3e",
    "children": ["15596e", "c19a95"],
    "settings": { "_cssGlobalClasses": ["zoyzsf"] },
    "label": "Button Group"
  },
  {
    "id": "15596e",
    "name": "button",
    "parent": "9b4d18",
    "children": [],
    "settings": { "text": "Button" }
  },
  {
    "id": "c19a95",
    "name": "button",
    "parent": "9b4d18",
    "children": [],
    "settings": { "text": "Button Outline", "outline": true }
  },
  {
    "id": "19454c",
    "name": "block",
    "parent": "65f029",
    "children": ["849138"],
    "settings": { "_cssGlobalClasses": ["vxsvbb"] },
    "label": "Media Wrapper"
  },
  {
    "id": "849138",
    "name": "image",
    "parent": "19454c",
    "children": [],
    "settings": {
      "tag": "figure",
      "caption": "none",
      "image": {
        "id": 90346,
        "filename": "image_16-9_portrait.jpg",
        "size": "medium_large",
        "full": "https://example.com/wp-content/uploads/image_16-9_portrait.jpg",
        "url": "https://example.com/wp-content/uploads/image_16-9_portrait-768x1365.jpg"
      },
      "_cssGlobalClasses": ["zqibqu"],
      "loading": "eager"
    },
    "label": "Media",
    "themeStyles": []
  }
]
```

## Schema categories

### [Elements](./elements/accordion/)

Individual element schemas describing the settings, metadata, and value types for each element type. 184 element schemas available.

#### [Common](./elements/common/element/)

Shared element documentation: the [element schema](./elements/common/element/) (envelope, settings layers, meta-settings, selectors), [element conditions](./elements/common/conditions/) (display conditions with 32 condition keys and comparison operators), and [element interactions](./elements/common/interactions/) (event-driven behavior with triggers, actions, and sub-conditions).

### [General](./general/content-area/)

Foundational data structures: the [content area](./general/content-area/) schema (flat array container, storage, and meta keys).

### [Controls](./controls/text/)

Value schemas for each control type (text, select, checkbox, typography, etc.), describing the shape of data each control produces.

### [Global](./global/global-classes/)

Root schemas for global data structures: global classes, theme styles, components, color palettes, breakpoints, pseudo-classes, and global variables.

### [Settings](./settings/page/)

Page and template settings schemas describing the available settings controls.

---

# Align Items Control Schema

Source: https://academy.bricksbuilder.io/developer/schema/controls/align-items/

*Value schema for align-items control type*

---

# Audio Control Schema

Source: https://academy.bricksbuilder.io/developer/schema/controls/audio/

*Value schema for audio control type*

## Properties

| Property | Type | Description |
|---|---|---|
| `id` | string \| integer | — |
| `url` | string | — |
| `autoplay` | boolean | — |
| `loop` | boolean | — |
| `controls` | boolean | — |

---

# Border Control Schema

Source: https://academy.bricksbuilder.io/developer/schema/controls/border/

*Value schema for border control type*

## Properties

| Property | Type | Description |
|---|---|---|
| `width` | object | Spacing value with directional properties |
| `style` | string | One of: `none`, `solid`, `dashed`, `dotted`, `double`, `groove`, `ridge`, `inset`, `outset` |
| `color` | any | Color value in various formats |
| `radius` | object | Spacing value with directional properties |

---

# Background Control Schema

Source: https://academy.bricksbuilder.io/developer/schema/controls/background/

*Value schema for background control type*

## Properties

| Property | Type | Description |
|---|---|---|
| `color` | any | Color value in various formats |
| `image` | object | Image settings |
| `video` | object | Video settings |
| `size` | string | — |
| `position` | string | — |
| `repeat` | string | One of: `repeat`, `repeat-x`, `repeat-y`, `no-repeat` |
| `attachment` | string | One of: `scroll`, `fixed`, `local` |

---

# Box Shadow Control Schema

Source: https://academy.bricksbuilder.io/developer/schema/controls/box-shadow/

*Value schema for box-shadow control type*

## Properties

| Property | Type | Description |
|---|---|---|
| `values` | array | — |

---

# Checkbox Control Schema

Source: https://academy.bricksbuilder.io/developer/schema/controls/checkbox/

*Value schema for checkbox control type*

---

# Button Control Schema

Source: https://academy.bricksbuilder.io/developer/schema/controls/button/

*UI-only control, no stored value*

---

# Code Control Schema

Source: https://academy.bricksbuilder.io/developer/schema/controls/code/

*Value schema for code control type*

---

# Color Control Schema

Source: https://academy.bricksbuilder.io/developer/schema/controls/color/

*Value schema for color control type*

---

# Datepicker Control Schema

Source: https://academy.bricksbuilder.io/developer/schema/controls/datepicker/

*Date/time string*

---

# Dimensions Control Schema

Source: https://academy.bricksbuilder.io/developer/schema/controls/dimensions/

*Value schema for dimensions control type*

## Properties

| Property | Type | Description |
|---|---|---|
| `top` | string | Top spacing value with unit |
| `right` | string | Right spacing value with unit |
| `bottom` | string | Bottom spacing value with unit |
| `left` | string | Left spacing value with unit |

---

# Direction Control Schema

Source: https://academy.bricksbuilder.io/developer/schema/controls/direction/

*Value schema for direction control type*

---

# Editor Control Schema

Source: https://academy.bricksbuilder.io/developer/schema/controls/editor/

*Rich text/HTML content*

---

# Filter Definition Manager Control Schema

Source: https://academy.bricksbuilder.io/developer/schema/controls/filter-definition-manager/

*Global filter ID, or an empty string for a local filter*

---

# Filters Control Schema

Source: https://academy.bricksbuilder.io/developer/schema/controls/filters/

*Value schema for filters control type*

## Properties

| Property | Type | Description |
|---|---|---|
| `blur` | string | — |
| `brightness` | string | — |
| `contrast` | string | — |
| `grayscale` | string | — |
| `hue-rotate` | string | — |
| `invert` | string | — |
| `opacity` | string | — |
| `saturate` | string | — |
| `sepia` | string | — |

---

# File Control Schema

Source: https://academy.bricksbuilder.io/developer/schema/controls/file/

*Value schema for file control type*

## Properties

| Property | Type | Description |
|---|---|---|
| `id` | string \| integer | — |
| `url` | string | — |

---

# Icon Control Schema

Source: https://academy.bricksbuilder.io/developer/schema/controls/icon/

*Value schema for icon control type*

## Properties

| Property | Type | Description |
|---|---|---|
| `library` | string | — |
| `icon` | string | — |
| `svg` | object | — |

---

# Image Control Schema

Source: https://academy.bricksbuilder.io/developer/schema/controls/image/

*Value schema for image control type*

## Properties

| Property | Type | Description |
|---|---|---|
| `id` | string \| integer | — |
| `filename` | string | — |
| `url` | string | — |
| `size` | string | — |
| `full` | string | — |
| `useDynamicData` | string | — |

---

# Image Gallery Control Schema

Source: https://academy.bricksbuilder.io/developer/schema/controls/image-gallery/

*Value schema for image-gallery control type*

## Properties

| Property | Type | Description |
|---|---|---|
| `images` | array | — |

---

# Justify Content Control Schema

Source: https://academy.bricksbuilder.io/developer/schema/controls/justify-content/

*Value schema for justify-content control type*

---

# Link Control Schema

Source: https://academy.bricksbuilder.io/developer/schema/controls/link/

*Value schema for link control type*

## Properties

| Property | Type | Description |
|---|---|---|
| `type` | string | — |
| `url` | string | — |
| `postId` | string \| integer | — |
| `newTab` | boolean | — |
| `rel` | string | — |
| `title` | string | — |
| `ariaLabel` | string | — |
| `lightboxId` | string | — |
| `lightboxType` | string | — |

---

# Number Control Schema

Source: https://academy.bricksbuilder.io/developer/schema/controls/number/

*Value schema for number control type*

---

# Query List Control Schema

Source: https://academy.bricksbuilder.io/developer/schema/controls/query-list/

*Element ID of the target query loop*

---

# Query Control Schema

Source: https://academy.bricksbuilder.io/developer/schema/controls/query/

*Value schema for query control type*

## Properties

| Property | Type | Description |
|---|---|---|
| `NOTE` | any | — |
| `api_auth_api_key_name` | any | — |
| `api_auth_api_key_use_constant` | any | — |
| `api_auth_api_key_use_constant_info` | any | — |
| `api_auth_api_key_value` | any | — |
| `api_auth_api_location` | any | — |
| `api_auth_basic_password` | any | — |
| `api_auth_basic_use_constant` | any | — |
| `api_auth_basic_use_constant_info` | any | — |
| `api_auth_basic_username` | any | — |
| `api_auth_bearer_token` | any | — |
| `api_auth_bearer_use_constant` | any | — |
| `api_auth_bearer_use_constant_info` | any | — |
| `api_auth_sep` | any | — |
| `api_auth_type` | any | — |
| `api_body_json` | any | — |
| `api_body_params` | any | — |
| `api_body_type` | any | — |
| `api_docs` | any | — |
| `api_headers` | any | — |
| `api_method` | any | — |
| `api_name` | any | — |
| `api_params` | any | — |
| `api_params_sep` | any | — |
| `api_sep` | any | — |
| `api_url` | any | — |
| `body_separator` | any | — |
| `cache_time` | any | — |
| `headers_separator` | any | — |
| `id` | any | — |
| `objectType` | any | — |
| `pagination_enabled` | any | — |
| `pagination_method` | any | — |
| `pagination_page_offset_key` | any | — |
| `pagination_page_offset_key_location` | any | — |
| `pagination_page_param` | any | — |
| `pagination_param_location` | any | — |
| `pagination_separator` | any | — |
| `pagination_total_extract` | any | — |
| `response_path` | any | — |
| `response_separator` | any | — |

---

# Radio Control Schema

Source: https://academy.bricksbuilder.io/developer/schema/controls/radio/

*Selected option key*

---

# Repeater Control Schema

Source: https://academy.bricksbuilder.io/developer/schema/controls/repeater/

*Repeatable fields array*

---

# Select Control Schema

Source: https://academy.bricksbuilder.io/developer/schema/controls/select/

*Value schema for select control type*

---

# Svg Control Schema

Source: https://academy.bricksbuilder.io/developer/schema/controls/svg/

*Value schema for svg control type*

## Properties

| Property | Type | Description |
|---|---|---|
| `id` | string \| integer | — |
| `url` | string | — |
| `library` | string | — |

---

# Spacing Control Schema

Source: https://academy.bricksbuilder.io/developer/schema/controls/spacing/

*Value schema for spacing control type*

## Properties

| Property | Type | Description |
|---|---|---|
| `top` | string | Top spacing value with unit |
| `right` | string | Right spacing value with unit |
| `bottom` | string | Bottom spacing value with unit |
| `left` | string | Left spacing value with unit |

---

# Text Align Control Schema

Source: https://academy.bricksbuilder.io/developer/schema/controls/text-align/

*Value schema for text-align control type*

---

# Text Shadow Control Schema

Source: https://academy.bricksbuilder.io/developer/schema/controls/text-shadow/

*Value schema for text-shadow control type*

## Properties

| Property | Type | Description |
|---|---|---|
| `values` | object | — |
| `color` | any | Color value in various formats |

---

# Text Control Schema

Source: https://academy.bricksbuilder.io/developer/schema/controls/text/

*Value schema for text control type*

---

# Textarea Control Schema

Source: https://academy.bricksbuilder.io/developer/schema/controls/textarea/

*Value schema for textarea control type*

---

# Transform Control Schema

Source: https://academy.bricksbuilder.io/developer/schema/controls/transform/

*Value schema for transform control type*

## Properties

| Property | Type | Description |
|---|---|---|
| `translateX` | string | — |
| `translateY` | string | — |
| `translateZ` | string | — |
| `scaleX` | string | — |
| `scaleY` | string | — |
| `scaleZ` | string | — |
| `rotateX` | string | — |
| `rotateY` | string | — |
| `rotateZ` | string | — |
| `skewX` | string | — |
| `skewY` | string | — |
| `perspective` | string | — |

---

# Typography Control Schema

Source: https://academy.bricksbuilder.io/developer/schema/controls/typography/

*Value schema for typography control type*

## Properties

| Property | Type | Description |
|---|---|---|
| `font-family` | string | — |
| `fallback` | string | Font stack appended to font-family, e.g. "Arial, sans-serif" |
| `font-size` | string | — |
| `font-weight` | string \| integer | — |
| `font-style` | string | One of: `normal`, `italic`, `oblique` |
| `line-height` | string | — |
| `letter-spacing` | string | — |
| `text-align` | string | One of: `left`, `center`, `right`, `justify` |
| `text-transform` | string | One of: `none`, `uppercase`, `lowercase`, `capitalize` |
| `text-decoration` | string | — |
| `color` | any | Color value in various formats |
| `font-variants` | array | Font variants to load (theme style Body and All headings typography only). Not output as CSS. |
| `font-variation-settings` | string | — |
| `white-space` | string | — |
| `text-wrap` | string | — |
| `text-shadow` | object | Text shadow settings |

---

# Video Control Schema

Source: https://academy.bricksbuilder.io/developer/schema/controls/video/

*Value schema for video control type*

## Properties

| Property | Type | Description |
|---|---|---|
| `source` | string | One of: `media`, `youtube`, `vimeo`, `url` |
| `id` | string \| integer | — |
| `url` | string | — |
| `youtubeId` | string | — |
| `vimeoId` | string | — |
| `autoplay` | boolean | — |
| `loop` | boolean | — |
| `muted` | boolean | — |
| `controls` | boolean | — |

---

# Content Area Schema

Source: https://academy.bricksbuilder.io/developer/schema/general/content-area/

*A Bricks content area is a flat array of elements stored in post meta. This page documents the array structure and storage.*

A content area is a flat array of element objects. Bricks uses three independent content areas per page (header, content, and footer), each stored in its own post meta key. The array is flat (not nested): parent-child relationships are expressed via the `parent` and `children` fields on each element.

For the structure of each element in the array, see the [Element schema](../elements/common/element/).

## Content areas

A Bricks page (or any post type using Bricks) stores its elements across three independent content areas:

| Content area | WordPress post meta key | Description |
|---|---|---|
| Header | `_bricks_page_header_2` | Header template elements |
| Content | `_bricks_page_content_2` | Main page/post content |
| Footer | `_bricks_page_footer_2` | Footer template elements |

All three use the exact same data structure: an array of elements as described in the [Element schema](../elements/common/element/).

## Storage

These are stored as serialized arrays in the `wp_postmeta` table.

| Data | Meta key | PHP constant |
|---|---|---|
| Header elements | `_bricks_page_header_2` | `BRICKS_DB_PAGE_HEADER` |
| Content elements | `_bricks_page_content_2` | `BRICKS_DB_PAGE_CONTENT` |
| Footer elements | `_bricks_page_footer_2` | `BRICKS_DB_PAGE_FOOTER` |

## Flat array structure

Elements reference each other by ID rather than nesting physically. A root-level element has `"parent": 0`; all others reference their parent's `id`. The `children` array on each element lists its direct children in order. This makes it easy to reorder, move, or flatten elements without restructuring a tree.

```json
[
  { "id": "aaa111", "name": "section", "parent": 0, "children": ["bbb222"], "settings": {} },
  { "id": "bbb222", "name": "heading", "parent": "aaa111", "children": [], "settings": { "text": "Hello" } }
]
```

The array may also contain component instances (identifiable by the presence of a `cid` field). See [Components](../global/components/) for details.

---

# Breakpoints Schema

Source: https://academy.bricksbuilder.io/developer/schema/global/breakpoints/

*Documentation for Breakpoints Schema in Bricks Academy.*

## Item properties

| Property | Type | Description |
|---|---|---|
| `key` | string | — |
| `label` | string | — |
| `width` | integer | — |
| `widthBuilder` | integer | — |
| `icon` | string | — |
| `base` | boolean | — |
| `custom` | boolean | — |
| `edited` | boolean | — |
| `paused` | boolean | — |

---

# Color Palettes Schema

Source: https://academy.bricksbuilder.io/developer/schema/global/color-palettes/

*Documentation for Color Palettes Schema in Bricks Academy.*

## Item properties

| Property | Type | Description |
|---|---|---|
| `id` | string | — |
| `name` | string | — |
| `colors` | array | — |

---

# Components Schema

Source: https://academy.bricksbuilder.io/developer/schema/global/components/

*Documentation for Components Schema in Bricks Academy.*

## Item properties

| Property | Type | Description |
|---|---|---|
| `id` | string | — |
| `category` | string | — |
| `desc` | string | — |
| `elements` | array | — |
| `properties` | array | — |
| `propertyGroups` | array | — |
| `_created` | integer \| string | — |
| `_user_id` | integer \| string | — |
| `_version` | string | — |
| `variants` | array | — |
| `blockEditor` | integer \| boolean | — |
| `blockCategory` | string | — |
| `blockIcon` | object | — |
| `blockPreviewImage` | object | Image settings |

---

# Global Variables Schema

Source: https://academy.bricksbuilder.io/developer/schema/global/global-variables/

*Documentation for Global Variables Schema in Bricks Academy.*

## Item properties

| Property | Type | Description |
|---|---|---|
| `id` | string | — |
| `name` | string | — |
| `value` | string | — |
| `category` | string | — |
| `type` | string | — |

---

# Global Classes Schema

Source: https://academy.bricksbuilder.io/developer/schema/global/global-classes/

*Documentation for Global Classes Schema in Bricks Academy.*

## Item properties

| Property | Type | Description |
|---|---|---|
| `id` | string | — |
| `name` | string | — |
| `category` | string | — |
| `settings` | dynamic | Dynamic map of all settings for this element or class. Keys are element-specific control names (e.g. `text`, `style`) or inherited CSS setting keys, optionally suffixed with a breakpoint and/or pseudo-class using colon syntax (e.g. `_typography:tablet_portrait:hover`). See the individual element schemas for available control keys. |
| `selectors` | array | Custom CSS selectors with scoped settings (since Bricks 2.0) |
| `modified` | integer \| string | — |
| `user_id` | integer \| string | — |
| `deletedAt` | integer \| string | — |

---

# Pseudo-Classes Schema

Source: https://academy.bricksbuilder.io/developer/schema/global/pseudo-classes/

*CSS pseudo-classes available in the builder for responsive/state variants. Stored as a WordPress option, user-configurable via Bricks settings.*

---

# Page Settings Schema

Source: https://academy.bricksbuilder.io/developer/schema/settings/page/

*Schema for Bricks page settings controls*

## Controls

| Key | Type | Label |
|---|---|---|
| `bodyClasses` | text | CSS classes |
| `customCss` | code | Custom CSS |
| `customScriptsBodyFooter` | code | Body (footer) scripts |
| `customScriptsBodyHeader` | code | Body (header) scripts |
| `customScriptsHeader` | code | Header scripts |
| `disableLazyLoad` | checkbox | Disable lazy load |
| `documentTitle` | text | Document title |
| `footerDisabled` | checkbox | Disable footer |
| `headerDisabled` | checkbox | Disable header |
| `metaDescription` | textarea | Meta description |
| `metaKeywords` | text | Meta keywords |
| `metaRobots` | select | Meta robots |
| `onePageNavigation` | checkbox | Show navigation |
| `onePageNavigationItemBorder` | border | Border |
| `onePageNavigationItemBorderActive` | border | Border |
| `onePageNavigationItemBoxShadow` | box-shadow | Box shadow |
| `onePageNavigationItemBoxShadowActive` | box-shadow | Box shadow |
| `onePageNavigationItemColor` | color | Color |
| `onePageNavigationItemColorActive` | color | Color |
| `onePageNavigationItemHeight` | number | Height |
| `onePageNavigationItemHeightActive` | number | Height |
| `onePageNavigationItemSpacing` | number | Spacing |
| `onePageNavigationItemWidth` | number | Width |
| `onePageNavigationItemWidthActive` | number | Width |
| `popupDisabled` | checkbox | Disable popups |
| `postName` | text | Permalink |
| `postTitle` | text | Title |
| `scrollMargin` | number | Margin |
| `scrollPadding` | number | Padding |
| `scrollSnapAlign` | select | Align |
| `scrollSnapSelector` | text | Snapping elements selector |
| `scrollSnapStop` | select | Stop |
| `scrollSnapType` | select | Type |
| `sharingDescription` | text | Description |
| `sharingImage` | image | Image |
| `sharingTitle` | text | Title |

---

# Template Settings Schema

Source: https://academy.bricksbuilder.io/developer/schema/settings/template/

*Schema for Bricks template settings controls*

## Controls

| Key | Type | Label |
|---|---|---|
| `footerReveal` | checkbox | Reveal effect |
| `headerPosition` | select | Header location |
| `headerSticky` | checkbox | Sticky header |
| `headerStickyOnScroll` | checkbox | Sticky on scroll |
| `headerStickyScrollingBackground` | background | Scrolling background |
| `headerStickyScrollingBoxShadow` | box-shadow | Scrolling box shadow |
| `headerStickyScrollingColor` | color | Scrolling text color |
| `headerStickyScrollingColorHover` | color | Scrolling text color |
| `headerStickySlideUpAfter` | number | Slide up after |
| `headerStickyTransition` | text | Transition |
| `headerWidth` | number | Header width |
| `passwordProtectionBypassLoggedIn` | checkbox | Disable for logged-in users |
| `passwordProtectionEndDate` | datepicker | End date |
| `passwordProtectionPassword` | text | Password |
| `passwordProtectionSchedule` | checkbox | Schedule |
| `passwordProtectionSource` | select | Password source |
| `passwordProtectionStartDate` | datepicker | Start date |
| `popupAjax` | checkbox | Fetch content via AJAX |
| `popupAjaxLoaderAnimation` | select | Animation |
| `popupAjaxLoaderColor` | color | Color |
| `popupAjaxLoaderScale` | number | Scale |
| `popupAjaxLoaderSelector` | text | CSS selector |
| `popupAlignItems` | align-items | Align cross axis |
| `popupBackdropTransition` | text | Transition |
| `popupBackground` | background | Background |
| `popupBodyScroll` | checkbox | Scroll |
| `popupBreakpointMode` | select | popupBreakpointMode |
| `popupCloseOn` | select | Close on |
| `popupContentBackground` | background | Background |
| `popupContentBorder` | border | Border |
| `popupContentBoxShadow` | box-shadow | Box shadow |
| `popupContentHeight` | number | Height |
| `popupContentMaxHeight` | number | Max. height |
| `popupContentMaxWidth` | number | Max. width |
| `popupContentMinHeight` | number | Min. height |
| `popupContentMinWidth` | number | Min. width |
| `popupContentPadding` | spacing | Padding |
| `popupContentWidth` | number | Width |
| `popupDisableAutoFocus` | checkbox | Disable auto focus |
| `popupDisableAutoFocusOnClose` | checkbox | Disable auto focus on close |
| `popupDisableBackdrop` | checkbox | Disable backdrop |
| `popupInfoBoxWidth` | number | Width |
| `popupIsInfoBox` | checkbox | Info Box |
| `popupIsWoo` | checkbox | WooCommerce  |
| `popupJustifyConent` | justify-content | Align main axis |
| `popupLimitLocalStorage` | number | Across sessions |
| `popupLimitSessionStorage` | number | Per session |
| `popupLimitTimeStorage` | number | Show again after .. hours |
| `popupLimitWindow` | number | Per page load |
| `popupPadding` | spacing | Padding |
| `popupScrollToTop` | checkbox | Scroll to top |
| `popupShowAt` | select | popupShowAt |
| `popupShowOn` | select | popupShowOn |
| `popupZindex` | number | Z-index |
| `searchCriteriaCustom` | checkbox | Custom search criteria |
| `searchPostFields` | checkbox | Search post fields |
| `searchPostMatchAnyWord` | checkbox | Match any word |
| `searchPostMeta` | checkbox | Search post meta fields |
| `searchPostMetaKeys` | repeater | Post meta keys |
| `searchPostQuery` | repeater | Post fields |
| `searchPostTaxonomies` | repeater | Taxonomies |
| `searchPostTerms` | checkbox | Search post terms |
| `templateConditions` | repeater | Archive type |
| `templatePreviewAuthor` | select | Author |
| `templatePreviewPostId` | select | Single |
| `templatePreviewPostType` | select | Post type |
| `templatePreviewSearchTerm` | text | Search term |
| `templatePreviewTerm` | select | Term |
| `templatePreviewType` | select | Content type |
| `template_interactions` | repeater | Interactions |
| `useWeightScore` | checkbox | Use weight score |

---

# Accordion (Nestable) Schema

Source: https://academy.bricksbuilder.io/developer/schema/elements/accordion-nested/

*Schema for Bricks Accordion (Nestable) element*

| Property | Value |
|---|---|
| `name` | accordion-nested |
| `category` | general |
| `tag` | div |
| `nestable` | true |

## Controls

| Key | Type | Label | CSS |
|---|---|---|---|
| `expandItem` | text | Expand item indexes | — |
| `independentToggle` | checkbox | Independent toggle | — |
| `transition` | number | Transition | — |
| `faqSchema` | checkbox | FAQ schema | — |
| `titleHeight` | number | Min. height | `min-height` on `.accordion-title-wrapper` |
| `titleMargin` | spacing | Margin | `margin` on `.accordion-title-wrapper` |
| `titlePadding` | spacing | Padding | `padding` on `.accordion-title-wrapper` |
| `titleBackgroundColor` | color | Background color | `background-color` on `.accordion-title-wrapper` |
| `titleBorder` | border | Border | `border` on `.accordion-title-wrapper` |
| `titleTypography` | typography | Typography | `font` on `.accordion-title-wrapper`, `font` on `.accordion-title-wrapper .brxe-heading` |
| `titleActiveBackgroundColor` | color | Background color | `background-color` on `.brx-open .accordion-title-wrapper` |
| `titleActiveBorder` | border | Border | `border` on `.brx-open .accordion-title-wrapper` |
| `titleActiveTypography` | typography | Typography | `font` on `.brx-open .accordion-title-wrapper`, `font` on `.brx-open .accordion-title-wrapper .brxe-heading` |
| `contentMargin` | spacing | Margin | `margin` on `.accordion-content-wrapper` |
| `contentPadding` | spacing | Padding | `padding` on `.accordion-content-wrapper` |
| `contentBackgroundColor` | color | Background color | `background-color` on `.accordion-content-wrapper` |
| `contentBorder` | border | Border | `border` on `.accordion-content-wrapper` |
| `contentTypography` | typography | Typography | `font` on `.accordion-content-wrapper` |

## Inherited CSS controls

Shared CSS controls available on all elements. Keys are prefixed with `_` and support responsive/pseudo-class variants via colon syntax (e.g. `_typography:tablet_portrait:hover`).

| Key | Type | Label | CSS |
|---|---|---|---|
| `_content` | text | Content | `content` |
| `_margin` | spacing | Margin | `margin` |
| `_padding` | spacing | Padding | `padding` |
| `_width` | number | Width | `width` |
| `_widthMin` | number | Min. width | `min-width` |
| `_widthMax` | number | Max. width | `max-width` |
| `_height` | number | Height | `height` |
| `_heightMin` | number | Min. height | `min-height` |
| `_heightMax` | number | Max. height | `max-height` |
| `_aspectRatio` | text | Aspect ratio | `aspect-ratio` |
| `_position` | select | Position | `position` |
| `_top` | number | _top | `top` |
| `_right` | number | Right | `right` |
| `_bottom` | number | Bottom | `bottom` |
| `_left` | number | Left | `left` |
| `_zIndex` | number | Z-index | `z-index` |
| `_order` | number | _order | `order` |
| `_display` | select | Display | `display`, `align-items` |
| `_columns` | text | Columns | `columns` |
| `_columnGap` | number | Column gap | `column-gap` |
| `_visibility` | select | Visibility | `visibility` |
| `_overflow` | text | Overflow | `overflow` |
| `_opacity` | number | Opacity | `opacity` |
| `_cursor` | select | Cursor | `cursor` |
| `_isolation` | select | Isolation | `isolation` |
| `_mixBlendMode` | select | Mix blend mode | `mix-blend-mode` |
| `_pointerEvents` | text | Pointer events | `pointer-events` |
| `_perspective` | number | Perspective | `perspective` |
| `_perspectiveOrigin` | text | Perspective origin | `perspective-origin` |
| `_gridItemJustifySelf` | align-items | Justify self | `justify-self` |
| `_flexDirection` | direction | Direction | `flex-direction` |
| `_alignSelf` | align-items | Align self | `align-self` |
| `_justifyContent` | justify-content | Align main axis | `justify-content` |
| `_alignItems` | align-items | Align cross axis | `align-items` |
| `_gap` | number | Gap | `gap` |
| `_flexGrow` | number | Flex grow | `flex-grow` |
| `_flexShrink` | number | Flex shrink | `flex-shrink` |
| `_flexBasis` | text | Flex basis | `flex-basis` |
| `_useMasonry` | checkbox | %s layout | — |
| `_masonryColumn` | number | Columns | `--columns` |
| `_masonryGutter` | number | Spacing | `--gutter` |
| `_masonryHorizontalOrder` | checkbox | Horizontal order | — |
| `_masonryTransitionDuration` | number | Transition | — |
| `_masonryTransitionMode` | select | Reveal animation | — |
| `_typography` | typography | _typography | `font` |
| `_background` | background | _background | `background` |
| `_shapeDividers` | repeater | Custom shape | — |
| `_gradient` | gradient | _gradient | `background-image` |
| `_border` | border | Border | `border` |
| `_boxShadow` | box-shadow | Box shadow | `box-shadow` |
| `_transform` | transform | Transform | `transform` |
| `_transformOrigin` | text | Transform origin | `transform-origin` |
| `_motionElementParallax` | checkbox | Element parallax | — |
| `_motionElementParallaxSpeedX` | number | Horizontal speed | `--brx-motion-parallax-speed-x` |
| `_motionElementParallaxSpeedY` | number | Vertical speed | `--brx-motion-parallax-speed-y` |
| `_motionBackgroundParallax` | checkbox | Background parallax | — |
| `_motionBackgroundParallaxSpeed` | number | Background speed | `--brx-motion-background-speed` |
| `_motionStartVisiblePercent` | number | Parallax start point | — |
| `_cssCustom` | code | Custom CSS | — |
| `_cssClasses` | text | CSS classes | — |
| `_cssId` | text | CSS ID | — |
| `_cssFilters` | filters | CSS Filters | `filter` |
| `_cssTransition` | text | Transition | `transition` |
| `_attributes` | repeater | Name | — |
| `_scrollSnapType` | select | Type | `scroll-snap-type` on `html`, `scroll-snap-align` on `.brxe-section` |
| `_scrollSnapAlign` | select | Align | `scroll-snap-align` on `.brxe-section` |
| `_scrollSnapStop` | select | Stop | `scroll-snap-stop` on `.brxe-section` |
