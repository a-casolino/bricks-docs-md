# Divider

Source: https://academy.bricksbuilder.io/builder/elements/layout/divider/

*The Divider element creates horizontal or vertical separator lines with optional icons.*

The Divider element creates horizontal or vertical separator lines with optional icons.

## Settings

- **Height** (number with units) - The height/thickness of the divider line. Default: 1.

- **Width** (number with units) - The width/length of the divider line.

- **Style** (select) - The line style. Options: `solid`, `dashed`, `dotted`, `double`, `groove`, `ridge`, `inset`, `outset`. Default: `solid`.

- **Direction** (select) - Orientation of the divider. Options: `horizontal`, `vertical`. Default: `horizontal`.

- **Align** (justify-content) - Alignment of the divider within its container. Options: `flex-start`, `center`, `flex-end`.

- **Color** (color) - Color of the divider line and icon.

### Icon

- **Icon** (icon) - Add an icon that appears on the divider line.

- **Typography** (typography) - Style settings for the icon (size, font properties). Only available when an icon is selected.

> **Developer reference**
>
> See the [Divider Schema](https://academy.bricksbuilder.io/developer/schema/elements/divider/) for the full JSON schema of this element's settings and controls.
