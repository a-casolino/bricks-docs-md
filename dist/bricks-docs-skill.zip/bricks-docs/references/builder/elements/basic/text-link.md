# Text Link

Source: https://academy.bricksbuilder.io/builder/elements/basic/text-link/

*The Text Link element creates a clickable text link with optional icon and advanced styling options.*

The Text Link element creates a clickable text link with optional icon and advanced styling options.

## Settings

- **Text** (text) - The link text to display. Default: "Text link".

- **Link to** (link) - Configure the link URL, target, and attributes.

### Icon

- **Icon** (icon) - Add an icon to the link.

- **Size** (number with units) - Icon size. Only available when an icon is selected.

- **Width** (number with units) - Icon container width. Only available when an icon is selected.

- **Height** (number with units) - Icon container height. Only available when an icon is selected.

- **Color** (color) - Icon color (applies to icon font color and SVG fill). Only available when an icon is selected.

- **Background color** (color) - Icon background color. Only available when an icon is selected.

- **Border** (border) - Icon border styling. Only available when an icon is selected.

- **Position** (select) - Icon placement relative to text. Options: `left`, `right`. Default: `right`. Only available when an icon is selected.

- **Gap** (number with units) - Space between the icon and text. Only available when an icon is selected.

> **Developer reference**
>
> See the [Text Link Schema](https://academy.bricksbuilder.io/developer/schema/elements/text-link/) for the full JSON schema of this element's settings and controls.
