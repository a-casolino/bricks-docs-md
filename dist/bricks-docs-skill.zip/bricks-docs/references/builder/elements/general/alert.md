# Alert

Source: https://academy.bricksbuilder.io/builder/elements/general/alert/

*The Alert element displays informational messages with different types and optional dismiss functionality.*

The Alert element displays informational messages with different types and optional dismiss functionality.

## Settings

- **Content** (rich text) - The alert message content. Supports dynamic data and rich text.

- **Type** (select) - The alert style type. Options: `info`, `success`, `warning`, `danger`, `muted`. Default: `info`.

- **Dismissable** (checkbox) - Adds a close button to allow users to dismiss the alert.

> **Developer reference**
>
> See the [Alert Schema](https://academy.bricksbuilder.io/developer/schema/elements/alert/) for the full JSON schema of this element's settings and controls.
