# Facebook page

Source: https://academy.bricksbuilder.io/builder/elements/general/facebook-page/

*The Facebook Page element embeds a Facebook page plugin with customizable display options.*

The Facebook Page element embeds a Facebook page plugin with customizable display options.

## Settings

- **Facebook page URL** (text) - The URL of the Facebook page to embed. Default: "https://facebook.com/facebook".

- **Height (px)** (number) - Height of the embedded page in pixels. Minimum: 70, Maximum: 500. Default: 500.

- **Width (px)** (number) - Width of the embedded page in pixels. Minimum: 180, Maximum: 500. Default: 340.

- **Tabs** (select) - Tabs to display on the page plugin. Options: `timeline`, `events`, `messages`. Multiple selection allowed.

- **Hide cover** (checkbox) - Hide the page cover photo.

- **Show friends' photos** (checkbox) - Display profile photos of the page's friends.

- **Hide CTA button** (checkbox) - Hide the call-to-action button.

- **Small header** (checkbox) - Use a smaller header size.

> **Developer reference**
>
> See the [Facebook Page Schema](https://academy.bricksbuilder.io/developer/schema/elements/facebook-page/) for the full JSON schema of this element's settings and controls.
