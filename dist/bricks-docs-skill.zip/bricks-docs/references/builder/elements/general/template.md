# Template

Source: https://academy.bricksbuilder.io/builder/elements/general/template/

*The Template element allows including reusable Bricks templates (sections, content, or popups) within a page.*

The Template element allows including reusable Bricks templates (sections, content, or popups) within a page.

## Settings

- **Template** (select) - Select a published Bricks template to include. Options include section, content, and popup templates.

- **Render without wrapper** (checkbox) - Render the template content directly without the outer div wrapper. Note: Style settings won't apply when this is enabled.

> **Developer reference**
>
> See the [Template Schema](https://academy.bricksbuilder.io/developer/schema/elements/template/) for the full JSON schema of this element's settings and controls.
