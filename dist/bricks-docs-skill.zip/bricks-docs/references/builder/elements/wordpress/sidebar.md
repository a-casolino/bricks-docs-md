# Sidebar

Source: https://academy.bricksbuilder.io/builder/elements/wordpress/sidebar/

*Displays a WordPress sidebar with its widgets.*

Displays a WordPress sidebar with its widgets.

## Settings

- **Sidebar** (select) - Select which sidebar to display. Default: none.
- **Widget margin** (spacing) - Set the margin for widgets. Default: 0 0 40px 0.
- **Title typography** (typography) - Typography settings for widget titles.
- **Content typography** (typography) - Typography settings for widget content.
- **Search background color** (color) - Background color for search inputs in widgets.
- **Search border** (border) - Border settings for search inputs in widgets.

> **Developer reference**
>
> See the [Sidebar Schema](https://academy.bricksbuilder.io/developer/schema/elements/sidebar/) for the full JSON schema of this element's settings and controls.
