# Account - Edit account

Source: https://academy.bricksbuilder.io/builder/elements/woocommerce/account-form-edit-account/

*Displays the Edit account form inside My Account.*

Displays the Edit account form inside My Account.

## Where this element works

My Account templates and My Account endpoint views.

## Key settings

- **Label typography** (typography)
- **Margin** (spacing)
- **Padding** (spacing)
- **Background color** (color)
- **Border** (border)
- **Box shadow** (box-shadow)
- **Typography** (typography)
- **Width** (number)
- **Gap** (number)

## Usage tips

- Use these elements in My Account templates or endpoint-specific templates.
- Verify each endpoint (orders, downloads, addresses, payment methods) so navigation and forms stay consistent.
