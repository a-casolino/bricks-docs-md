# Account - Reset password

Source: https://academy.bricksbuilder.io/builder/elements/woocommerce/account-form-reset-password/

*Displays the Reset password form used after password reset link validation.*

Displays the Reset password form used after password reset link validation.

## Where this element works

My Account templates and My Account endpoint views.

## Key settings

- **Disable** (checkbox)
- **Typography** (typography)
- **Align items** (align-items)
- **Width** (number)
- **Gap** (number)
- **Label typography** (typography)
- **Field** (separator)
- **Margin** (spacing)
- **Padding** (spacing)
- **Background color** (color)

## Usage tips

- Use these elements in My Account templates or endpoint-specific templates.
- Verify each endpoint (orders, downloads, addresses, payment methods) so navigation and forms stay consistent.
