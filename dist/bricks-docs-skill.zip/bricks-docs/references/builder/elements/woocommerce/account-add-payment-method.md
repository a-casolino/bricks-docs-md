# Account - Add payment method

Source: https://academy.bricksbuilder.io/builder/elements/woocommerce/account-add-payment-method/

*Displays the Add payment method endpoint content inside My Account templates.*

Displays the Add payment method endpoint content inside My Account templates.

## Where this element works

My Account templates and My Account endpoint views.

## Key settings

- **Wrapper** (separator)
- **Payment Methods List** (separator)
- **Payment Method Item** (separator)
- **Label** (separator)
- **Custom Radio (Checked)** (separator)
- **Color** (color)
- **Payment Box** (separator)
- **Add Payment Method Button** (separator)
- **Margin** (spacing)
- **Padding** (spacing)

## Usage tips

- Use these elements in My Account templates or endpoint-specific templates.
- Verify each endpoint (orders, downloads, addresses, payment methods) so navigation and forms stay consistent.
