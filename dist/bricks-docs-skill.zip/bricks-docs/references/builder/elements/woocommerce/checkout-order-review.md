# Checkout order review

Source: https://academy.bricksbuilder.io/builder/elements/woocommerce/checkout-order-review/

*Displays the order review section on Checkout.*

Displays the order review section on Checkout.

## Where this element works

Checkout templates (and order-received context for thank-you flows).

## Key settings

- **Hide title** (checkbox)
- **Title** (text)
- **Title typography** (typography)
- **Subtitles typography** (typography)
- **Items** (separator)
- **Typography** (typography)
- **Padding** (spacing)
- **Border** (border)
- **Margin** (spacing)
- **Background** (color)

## Usage tips

- Use checkout elements only in Checkout templates so forms and order data render correctly.
- Test logged-in and guest checkout flows after styling changes to ensure all states remain usable.
