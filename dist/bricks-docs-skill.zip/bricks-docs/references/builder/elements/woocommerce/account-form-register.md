# Account - Register form

Source: https://academy.bricksbuilder.io/builder/elements/woocommerce/account-form-register/

*Displays the WooCommerce account registration form.*

Displays the WooCommerce account registration form.

## Where this element works

My Account templates and My Account endpoint views.

## Key settings

- **Generate password** (separator)
- **Typography** (typography)
- **Privacy policy** (separator)
- **Link** (typography)
- **Align items** (align-items)
- **Width** (number)
- **Gap** (number)
- **Label typography** (typography)
- **Field** (separator)
- **Margin** (spacing)

## Usage tips

- Use these elements in My Account templates or endpoint-specific templates.
- Verify each endpoint (orders, downloads, addresses, payment methods) so navigation and forms stay consistent.
