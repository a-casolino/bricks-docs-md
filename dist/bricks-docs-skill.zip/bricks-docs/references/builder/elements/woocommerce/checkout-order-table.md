# Checkout order table

Source: https://academy.bricksbuilder.io/builder/elements/woocommerce/checkout-order-table/

*Displays the checkout order table with line items, totals, and taxes.*

Displays the checkout order table with line items, totals, and taxes.

## Where this element works

Checkout templates (and order-received context for thank-you flows).

## Key settings

- **Preview order ID** (number)
- **Padding** (spacing)
- **Background** (color)
- **Border** (border)
- **Typography** (typography)

## Usage tips

- Use checkout elements only in Checkout templates so forms and order data render correctly.
- Test logged-in and guest checkout flows after styling changes to ensure all states remain usable.
