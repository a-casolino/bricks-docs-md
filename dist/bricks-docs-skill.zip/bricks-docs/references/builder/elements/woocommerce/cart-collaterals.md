# Cart totals

Source: https://academy.bricksbuilder.io/builder/elements/woocommerce/cart-collaterals/

*Displays cart totals and related collateral content from the Cart page.*

Displays cart totals and related collateral content from the Cart page.

## Where this element works

Cart page templates.

## Key settings

- **Disable cross sells** (checkbox)
- **Hide title** (checkbox)
- **Title** (typography)
- **Subtotal** (typography)
- **Total** (typography)
- **Table** (separator)
- **Margin** (spacing)
- **Padding** (spacing)
- **Border** (border)
- **Button** (separator)

## Usage tips

- Place cart elements in a dedicated Cart template to avoid empty output on non-cart pages.
- Keep spacing and table styling consistent across cart rows, totals, and coupon sections for better usability.
