# Hover Styles

Source: https://academy.bricksbuilder.io/builder/styling/hover-styles/

*Style hover states in Bricks so links, buttons, cards, and other interactive elements respond consistently.*

Bring your site to life and boost visitor engagement by styling the hover state of any interactive element.

In the builder, select the element or class you want to style. Open the pseudo-class menu and choose `:hover`. Any styles you add while `:hover` is active are saved to that hover state instead of the default state.

Use the same pseudo-class workflow for global classes, element ID styles, and other supported states. Learn more in [Styling Element States & Parts](https://academy.bricksbuilder.io/builder/styling/pseudo-classes/).
