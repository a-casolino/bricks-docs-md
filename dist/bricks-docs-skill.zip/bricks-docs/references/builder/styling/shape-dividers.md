# Shape Dividers

Source: https://academy.bricksbuilder.io/builder/styling/shape-dividers/

*Add and style shape dividers in Bricks to separate sections with SVG-based visual transitions.*

Give your design an edge by adding an unlimited number of shape dividers such as tilts, drops, grids, clouds, strokes, triangles, waves, etc. to layout elements: Section, Container, Block, and Div.

Shape dividers are available in the element style panel under **Shape Dividers**. You can add multiple dividers, choose a bundled shape or custom SVG, and control fill color, front/back placement, flipping, overflow, size, rotation, alignment, and offsets.

https://youtu.be/rXhgQ5fsKDc
