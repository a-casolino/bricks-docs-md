# Elements

Source: https://academy.bricksbuilder.io/builder/elements/

*Browse the built-in Bricks elements across layout, content, WordPress, WooCommerce, media, filters, and query-related use cases.*

These are the elements that Bricks comes with:

## Layout

- [Container](https://academy.bricksbuilder.io/builder/elements/layout/container/)
- [Block](https://academy.bricksbuilder.io/builder/elements/layout/block/)
- [Section](https://academy.bricksbuilder.io/builder/elements/layout/section/)
- [Div](https://academy.bricksbuilder.io/builder/elements/layout/div/)
- [Divider](https://academy.bricksbuilder.io/builder/elements/layout/divider/)
- [List](https://academy.bricksbuilder.io/builder/elements/layout/list/)

## Basic

- [Heading](https://academy.bricksbuilder.io/builder/elements/basic/heading/)
- [Text Basic](https://academy.bricksbuilder.io/builder/elements/basic/text-basic/)
- [Rich Text](https://academy.bricksbuilder.io/builder/elements/basic/text/)
- [Text Link](https://academy.bricksbuilder.io/builder/elements/basic/text-link/)
- [Button](https://academy.bricksbuilder.io/builder/elements/basic/button/)
- [Icon](https://academy.bricksbuilder.io/builder/elements/basic/icon/)
- [Image](https://academy.bricksbuilder.io/builder/elements/basic/image/)
- [Video](https://academy.bricksbuilder.io/builder/elements/basic/video/)

## General

- [Icon Box](https://academy.bricksbuilder.io/builder/elements/general/icon-box/)
- [Icon List](https://academy.bricksbuilder.io/builder/elements/general/icon-list/)
- [Accordion](https://academy.bricksbuilder.io/builder/elements/general/accordion/)
- [Accordion (Nestable)](https://academy.bricksbuilder.io/builder/elements/general/accordion-nested/)
- [Tabs](https://academy.bricksbuilder.io/builder/elements/general/tabs/)
- [Tabs (Nestable)](https://academy.bricksbuilder.io/builder/elements/general/tabs-nested/)
- [Form](https://academy.bricksbuilder.io/builder/elements/general/form/)
- [Map](https://academy.bricksbuilder.io/builder/elements/general/map/)
- [Map (Leaflet)](https://academy.bricksbuilder.io/builder/elements/general/map-leaflet/)
- [Map Connector](https://academy.bricksbuilder.io/builder/elements/general/map-connector/)
- [Alert](https://academy.bricksbuilder.io/builder/elements/general/alert/)
- [Animated Typing](https://academy.bricksbuilder.io/builder/elements/general/animated-typing/)
- [Breadcrumbs](https://academy.bricksbuilder.io/builder/elements/general/breadcrumbs/)
- [Code](https://academy.bricksbuilder.io/builder/elements/general/code/)
- [HTML](https://academy.bricksbuilder.io/builder/elements/general/html/)
- [Countdown](https://academy.bricksbuilder.io/builder/elements/general/countdown/)
- [Counter](https://academy.bricksbuilder.io/builder/elements/general/counter/)
- [Pricing Tables](https://academy.bricksbuilder.io/builder/elements/general/pricing-tables/)
- [Progress Bar](https://academy.bricksbuilder.io/builder/elements/general/progress-bar/)
- [Rating](https://academy.bricksbuilder.io/builder/elements/general/rating/)
- [Pie Chart](https://academy.bricksbuilder.io/builder/elements/general/pie-chart/)
- [Team Members](https://academy.bricksbuilder.io/builder/elements/general/team-members/)
- [Testimonials](https://academy.bricksbuilder.io/builder/elements/general/testimonials/)
- [Nav (Nestable)](https://academy.bricksbuilder.io/builder/elements/general/nav-nested/)
- [Dropdown](https://academy.bricksbuilder.io/builder/elements/general/dropdown/)
- [Offcanvas](https://academy.bricksbuilder.io/builder/elements/general/offcanvas/)
- [Toggle](https://academy.bricksbuilder.io/builder/elements/general/toggle/)
- [Toggle - Mode](https://academy.bricksbuilder.io/builder/elements/general/toggle-mode/)
- [Back to Top](https://academy.bricksbuilder.io/builder/elements/general/back-to-top/)
- [Template](https://academy.bricksbuilder.io/builder/elements/general/template/)
- [Slot](https://academy.bricksbuilder.io/builder/elements/general/slot/)
- [Facebook Page](https://academy.bricksbuilder.io/builder/elements/general/facebook-page/)

## Media

- [Image Gallery](https://academy.bricksbuilder.io/builder/elements/media/image-gallery/)
- [Instagram feed](https://academy.bricksbuilder.io/builder/elements/media/instagram-feed/)
- [Audio](https://academy.bricksbuilder.io/builder/elements/media/audio/)
- [Carousel](https://academy.bricksbuilder.io/builder/elements/media/carousel/)
- [Logo](https://academy.bricksbuilder.io/builder/elements/media/logo/)
- [Slider](https://academy.bricksbuilder.io/builder/elements/media/slider/)
- [Slider (Nestable)](https://academy.bricksbuilder.io/builder/elements/media/slider-nested/)
- [SVG](https://academy.bricksbuilder.io/builder/elements/media/svg/)

## WordPress

- [WordPress](https://academy.bricksbuilder.io/builder/elements/wordpress/wordpress/)
- [Posts](https://academy.bricksbuilder.io/builder/elements/wordpress/posts/)
- [Pagination](https://academy.bricksbuilder.io/builder/elements/wordpress/pagination/)
- [Nav Menu](https://academy.bricksbuilder.io/builder/elements/wordpress/nav-menu/)
- [Sidebar](https://academy.bricksbuilder.io/builder/elements/wordpress/sidebar/)
- [Search](https://academy.bricksbuilder.io/builder/elements/wordpress/search/)
- [Shortcode](https://academy.bricksbuilder.io/builder/elements/wordpress/shortcode/)

## Single

- [Post Title](https://academy.bricksbuilder.io/builder/elements/single/post-title/)
- [Excerpt](https://academy.bricksbuilder.io/builder/elements/single/excerpt/)
- [Meta Data](https://academy.bricksbuilder.io/builder/elements/single/meta-data/)
- [Post Content](https://academy.bricksbuilder.io/builder/elements/single/post-content/)
- [Social Sharing](https://academy.bricksbuilder.io/builder/elements/single/social-sharing/)
- [Related Posts](https://academy.bricksbuilder.io/builder/elements/single/related-posts/)
- [Author](https://academy.bricksbuilder.io/builder/elements/single/author/)
- [Comments](https://academy.bricksbuilder.io/builder/elements/single/comments/)
- [Taxonomy](https://academy.bricksbuilder.io/builder/elements/single/taxonomy/)
- [Post Navigation](https://academy.bricksbuilder.io/builder/elements/single/post-navigation/)
- [Post Reading Progress Bar](https://academy.bricksbuilder.io/builder/elements/single/post-reading-progress-bar/)
- [Post Reading Time](https://academy.bricksbuilder.io/builder/elements/single/post-reading-time/)
- [Post Table of Contents](https://academy.bricksbuilder.io/builder/elements/single/post-toc/)

## Query

- [Query Results Summary](https://academy.bricksbuilder.io/builder/elements/query/query-results-summary/)

## Filter

- [Filter Active Filters](https://academy.bricksbuilder.io/builder/elements/filter/filter-active-filters/)
- [Filter Checkbox](https://academy.bricksbuilder.io/builder/elements/filter/filter-checkbox/)
- [Filter Datepicker](https://academy.bricksbuilder.io/builder/elements/filter/filter-datepicker/)
- [Filter Radio](https://academy.bricksbuilder.io/builder/elements/filter/filter-radio/)
- [Filter Range](https://academy.bricksbuilder.io/builder/elements/filter/filter-range/)
- [Filter Search](https://academy.bricksbuilder.io/builder/elements/filter/filter-search/)
- [Filter Select](https://academy.bricksbuilder.io/builder/elements/filter/filter-select/)
- [Filter Submit](https://academy.bricksbuilder.io/builder/elements/filter/filter-submit/)

## WooCommerce

- [WooCommerce Breadcrumbs](https://academy.bricksbuilder.io/builder/elements/woocommerce/breadcrumbs/)
- [Mini Cart](https://academy.bricksbuilder.io/builder/elements/woocommerce/mini-cart/)
- [Notice](https://academy.bricksbuilder.io/builder/elements/woocommerce/notice/)
- [Template Hook](https://academy.bricksbuilder.io/builder/elements/woocommerce/template-hook/)
- [Products](https://academy.bricksbuilder.io/builder/elements/woocommerce/products/)
- [Products Pagination](https://academy.bricksbuilder.io/builder/elements/woocommerce/products-pagination/)
- [Products Orderby](https://academy.bricksbuilder.io/builder/elements/woocommerce/products-orderby/)
- [Products Total Results](https://academy.bricksbuilder.io/builder/elements/woocommerce/products-total-results/)
- [Products Filter](https://academy.bricksbuilder.io/builder/elements/woocommerce/products-filter/)
- [Products Archive Description](https://academy.bricksbuilder.io/builder/elements/woocommerce/products-archive-description/)
- [Cart Items](https://academy.bricksbuilder.io/builder/elements/woocommerce/cart-items/)
- [Cart Coupon](https://academy.bricksbuilder.io/builder/elements/woocommerce/cart-coupon/)
- [Cart Collaterals](https://academy.bricksbuilder.io/builder/elements/woocommerce/cart-collaterals/)
- [Checkout Login](https://academy.bricksbuilder.io/builder/elements/woocommerce/checkout-login/)
- [Checkout Coupon](https://academy.bricksbuilder.io/builder/elements/woocommerce/checkout-coupon/)
- [Checkout Customer Details](https://academy.bricksbuilder.io/builder/elements/woocommerce/checkout-customer-details/)
- [Checkout Order Review](https://academy.bricksbuilder.io/builder/elements/woocommerce/checkout-order-review/)
- [Checkout Order Payment](https://academy.bricksbuilder.io/builder/elements/woocommerce/checkout-order-payment/)
- [Checkout Order Table](https://academy.bricksbuilder.io/builder/elements/woocommerce/checkout-order-table/)
- [Checkout Thankyou](https://academy.bricksbuilder.io/builder/elements/woocommerce/checkout-thankyou/)
- [Account Page](https://academy.bricksbuilder.io/builder/elements/woocommerce/account-page/)
- [Account Orders](https://academy.bricksbuilder.io/builder/elements/woocommerce/account-orders/)
- [Account Downloads](https://academy.bricksbuilder.io/builder/elements/woocommerce/account-downloads/)
- [Account Addresses](https://academy.bricksbuilder.io/builder/elements/woocommerce/account-addresses/)
- [Account Payment Methods](https://academy.bricksbuilder.io/builder/elements/woocommerce/account-payment-methods/)
- [Account Add Payment Method](https://academy.bricksbuilder.io/builder/elements/woocommerce/account-add-payment-method/)
- [Account View Order](https://academy.bricksbuilder.io/builder/elements/woocommerce/account-view-order/)
- [Account Form Login](https://academy.bricksbuilder.io/builder/elements/woocommerce/account-form-login/)
- [Account Form Register](https://academy.bricksbuilder.io/builder/elements/woocommerce/account-form-register/)
- [Account Form Lost Password](https://academy.bricksbuilder.io/builder/elements/woocommerce/account-form-lost-password/)
- [Account Form Reset Password](https://academy.bricksbuilder.io/builder/elements/woocommerce/account-form-reset-password/)
- [Account Form Edit Account](https://academy.bricksbuilder.io/builder/elements/woocommerce/account-form-edit-account/)
- [Account Form Edit Address](https://academy.bricksbuilder.io/builder/elements/woocommerce/account-form-edit-address/)

## Product

- [Product Title](https://academy.bricksbuilder.io/builder/elements/product/product-title/)
- [Product Gallery](https://academy.bricksbuilder.io/builder/elements/product/product-gallery/)
- [Product Short Description](https://academy.bricksbuilder.io/builder/elements/product/product-short-description/)
- [Product Price](https://academy.bricksbuilder.io/builder/elements/product/product-price/)
- [Product Stock](https://academy.bricksbuilder.io/builder/elements/product/product-stock/)
- [Product Meta](https://academy.bricksbuilder.io/builder/elements/product/product-meta/)
- [Product Rating](https://academy.bricksbuilder.io/builder/elements/product/product-rating/)
- [Product Content](https://academy.bricksbuilder.io/builder/elements/product/product-content/)
- [Add to Cart](https://academy.bricksbuilder.io/builder/elements/product/product-add-to-cart/)
- [Related Products](https://academy.bricksbuilder.io/builder/elements/product/product-related/)
- [Product Additional Information](https://academy.bricksbuilder.io/builder/elements/product/product-additional-information/)
- [Product Tabs](https://academy.bricksbuilder.io/builder/elements/product/product-tabs/)
- [Product Reviews](https://academy.bricksbuilder.io/builder/elements/product/product-reviews/)
- [Product Up/Cross-sells](https://academy.bricksbuilder.io/builder/elements/product/product-upsells/)

---

# Button

Source: https://academy.bricksbuilder.io/builder/elements/basic/button/

*The Button element creates clickable buttons with customizable styles, sizes, and optional icons.*

The Button element creates clickable buttons with customizable styles, sizes, and optional icons.

## Settings

- **Text** (text) - The button text label. Default: "I am a button".

- **HTML tag** (text) - The HTML tag to use for the button. Default: `span`. Changes to `a` automatically when a link is added.

- **Size** (select) - Predefined button size. Options vary based on theme settings (e.g., `sm`, `md`, `lg`). Default: Default size.

- **Style** (select) - Apply a predefined color style from your theme styles (e.g., `primary`, `secondary`, `success`, `danger`). Default: `primary`.

- **Circle** (checkbox) - Make the button circular (typically used for icon-only buttons).

- **Outline** (checkbox) - Apply an outline style instead of filled background.

### Link

- **Link type** (link) - Configure the button link behavior, URL, and attributes.

### Icon

- **Icon** (icon) - Add an icon to the button from the icon library.

- **Typography** (typography) - Style settings for the icon. Only available when an icon is selected.

- **Position** (select) - Icon placement relative to text. Options: `left`, `right`. Default: `right`.

- **Gap** (number with units) - Space between the icon and text.

- **Space between** (checkbox) - Distribute space between icon and text to push them to opposite ends of the button.

> **Developer reference**
>
> See the [Button Schema](https://academy.bricksbuilder.io/developer/schema/elements/button/) for the full JSON schema of this element's settings and controls.

---

# Heading

Source: https://academy.bricksbuilder.io/builder/elements/basic/heading/

*The Heading element displays text in heading tags (h1-h6) with optional separator lines and styling options.*

The Heading element displays text in heading tags (h1-h6) with optional separator lines and styling options.

## Settings

- **Text** (text) - The heading text content.

- **HTML tag** (select) - The heading level to use. Options: `h1`, `h2`, `h3`, `h4`, `h5`, `h6`, `custom`. Default: `h3`.

- **Custom tag** (text) - Specify a custom HTML tag name without attributes. Only available when HTML tag is set to "custom".

- **Type** (select) - Predefined heading type. Options: `hero`, `lead`. Default: None.

- **Style** (select) - Apply a predefined style from your theme styles. Default: None.

- **Link to** (link) - Make the heading clickable by adding a link.

### Separator

- **Separator** (select) - Add decorative lines beside the heading. Options: `right`, `left`, `both`, `none`. Default: None.

- **Width** (number with units) - The width of the separator lines.

- **Height** (number with units) - The height/thickness of the separator lines.

- **Spacing** (number with units) - Gap between the heading text and separator lines. Default: 20.

- **Style** (select) - The border style for separator lines. Options: `solid`, `dashed`, `dotted`, `double`, `groove`, `ridge`, `inset`, `outset`.

- **Align** (align-items) - Vertical alignment of the heading and separator lines. Options: `flex-start`, `center`, `flex-end`.

> **Developer reference**
>
> See the [Heading Schema](https://academy.bricksbuilder.io/developer/schema/elements/heading/) for the full JSON schema of this element's settings and controls.

---

# Icon

Source: https://academy.bricksbuilder.io/builder/elements/basic/icon/

*The Icon element displays an icon from various icon libraries or custom SVG icons.*

The Icon element displays an icon from various icon libraries or custom SVG icons.

## Settings

- **Icon** (icon) - Select an icon from the available icon libraries (Themify, Font Awesome, Ionicons, etc.). Default: `ti-star` from Themify library.

- **Color** (color) - The icon color. Applies to both icon font and SVG fill.

- **Size** (number with units) - The icon size using font-size property.

- **Link** (link) - Make the icon clickable by adding a link.

### Accordion integration

The following settings are only available when the icon is placed inside an Accordion (Nestable) element title wrapper:

- **Is Accordion (Nestable) Icon** (checkbox) - Enable accordion-specific behavior for the icon.

- **Show** (select) - Control icon visibility based on accordion state. Options: `collapsed`, `expanded`. Default: Always visible. When set to a specific state, duplicate the icon element and set different states to show different icons.

- **Transform (Expanded)** (transform) - CSS transform properties to apply when the accordion item is expanded. By default, icons rotate 90° when expanded.

> **Developer reference**
>
> See the [Icon Schema](https://academy.bricksbuilder.io/developer/schema/elements/icon/) for the full JSON schema of this element's settings and controls.

---

# Image

Source: https://academy.bricksbuilder.io/builder/elements/basic/image/

*The Image element displays images with support for responsive sources, captions, lightbox functionality, masks, and various other styling options.*

The Image element displays images with support for responsive sources, captions, lightbox functionality, masks, and various other styling options.

## Settings

### Basic

- **Image** (image) - Select an image from the media library or use dynamic data. Since Bricks 2.5, drop a local image onto the selector or preview to upload and select it. This changes the element's selection without replacing an existing Media Library attachment. See [Media Browser](https://academy.bricksbuilder.io/builder/features/media-browser/#drop-images-directly-onto-a-control).

- **HTML tag** (select) - The HTML tag to wrap the image. Options: `figure`, `picture`, `div`, `custom`. Default: `figure`. When sources are used, Bricks outputs a `<picture>` element around the image sources. If the image has a caption, Bricks keeps the `figure` wrapper and places the `<picture>` element inside it.

- **Custom tag** (text) - Specify a custom HTML tag name without attributes. Only available when HTML tag is set to "custom" and sources are not used.

- **Sources** (repeater) - Configure different images for different breakpoints using the `<picture>` element. Each source has:
  - **Breakpoint** (select) - Target breakpoint or custom media query
  - **Media query** (text) - Custom media query string (only when breakpoint is "Custom")
  - **Image** (image) - Image to display for this breakpoint

  Order matters because the browser uses the first matching `<source>` inside the generated `<picture>` element. Add sources for breakpoints below the base breakpoint first, from smallest to largest. Then add sources for breakpoints above the base breakpoint, from largest to smallest. Add the base breakpoint source last so it can act as the fallback image.

  Bricks generates `max-width` media queries for breakpoints below the base breakpoint and `min-width` media queries for breakpoints above the base breakpoint. For example, if Desktop is the base breakpoint and you add a Desktop XL breakpoint at `1890px`, the Desktop XL source uses `(min-width: 1890px)`. A Tablet portrait source below the base breakpoint uses its `max-width` condition.

  Choose **Custom** when you need to write the media query manually. Bricks uses the custom media query as entered, so keep it in the correct source order.

- **Aspect ratio** (text) - Set the image aspect ratio (e.g., `16/9`, `4/3`, `1/1`).

- **Object fit** (select) - How the image should fit its container. Options: `fill`, `contain`, `cover`, `none`, `scale-down`.

- **Object position** (text) - Position of the image within its container (e.g., `center center`, `top left`).

### Alt & Caption

- **Custom alt text** (text) - Override the default alt text from the media library.

- **Caption type** (select) - Display a caption below the image. Options: `none`, `attachment` (from media library), `custom`. Default: `attachment`.

- **Custom caption** (text) - Custom caption text. Only available when caption type is set to "custom".

### Display Options

- **Loading** (select) - Image loading behavior. Options: `eager`, `lazy`. Default: `lazy`.

- **Show title** (checkbox) - Display the image title attribute from the media library.

- **Stretch** (checkbox) - Make the image width 100% of its container.

- **Image Overlay** (color) - Add a color overlay on top of the image.

### Link To

- **Link** (select) - Make the image clickable. Options: `lightbox`, `attachment` (attachment page), `media` (media file), `url` (custom URL). Default: None.

#### Lightbox Settings

Available when link is set to "lightbox":

- **Image size** (select) - The image size to display in lightbox. Options based on registered image sizes. Default: Full.

- **Width** (number) - Custom lightbox image width in pixels.

- **Height** (number) - Custom lightbox image height in pixels.

- **Animation** (select) - Lightbox animation type. Options: `zoom`, `fade`, `none`. Default: `zoom`.

- **Caption** (checkbox) - Show image caption in lightbox.

- **ID** (text) - Group multiple images with the same lightbox ID to create a gallery.

- **Cropped** (checkbox) - Enable for smoother transitions if the image is cropped.

- **Padding** (dimensions) - Padding around the lightbox image in pixels.

#### Attachment/Media Settings

Available when link is set to "attachment" or "media":

- **Open in new tab** (checkbox) - Open the link in a new browser tab.

#### URL Settings

Available when link is set to "url":

- **URL** (link) - Configure the custom link URL and attributes.

### Icon

Optional icon overlay displayed when the image has a link:

- **Disable icon** (checkbox) - Hide the icon even if configured in theme styles.

- **Icon** (icon) - Select an icon to display on the image.

- **Icon background color** (color) - Background color for the icon.

- **Icon border** (border) - Border styling for the icon.

- **Icon box shadow** (box-shadow) - Box shadow for the icon.

- **Icon typography** (typography) - Typography settings for the icon (size, color).

- **Icon height** (number) - Height of the icon container.

- **Icon width** (number) - Width of the icon container.

- **Icon transition** (text) - CSS transition for the icon.

### Mask

Apply a mask to the image for creative shapes and effects:

- **Mask** (select) - Choose from predefined mask shapes or use a custom mask image. Options include:
  - **Custom** - Use a custom mask image
  - **Boom** - Boom shape mask
  - **Box** - Box shape mask
  - **Bubbles** - Bubbles pattern mask
  - **Circle dots** - Circle dots pattern mask
  - **Circle line** - Circle line pattern mask
  - **Circle waves** - Circle waves pattern mask
  - **Circle** - Circle shape mask
  - **Drop 2** - Drop 2 shape mask
  - **Drop** - Drop shape mask
  - **Fire** - Fire shape mask
  - **Grid circles** - Grid circles pattern mask
  - **Grid dots** - Grid dots pattern mask
  - **Grid filled diagonal** - Grid filled diagonal pattern mask
  - **Grid lines diagonal** - Grid lines diagonal pattern mask
  - **Grid** - Grid pattern mask
  - **Heart** - Heart shape mask
  - **Hexagon dent** - Hexagon dent shape mask
  - **Hexagon** - Hexagon shape mask
  - **Hourglass** - Hourglass shape mask
  - **Masonry** - Masonry pattern mask
  - **Ninja star** - Ninja star shape mask
  - **Octagon dent** - Octagon dent shape mask
  - **Play** - Play shape mask
  - **Plus** - Plus shape mask
  - **Round zig zag** - Round zig zag pattern mask
  - **Splash** - Splash shape mask
  - **Square rounded** - Square rounded shape mask
  - **Squares 3x3** - Squares 3x3 pattern mask
  - **Squares 4x4** - Squares 4x4 pattern mask
  - **Squares 4 diagonal rounded** - Squares 4 diagonal rounded pattern mask
  - **Squares 4 diagonal** - Squares 4 diagonal pattern mask
  - **Squares diagonal** - Squares diagonal pattern mask
  - **Squares merged** - Squares merged pattern mask
  - **Tiles 2** - Tiles 2 pattern mask
  - **Tiles** - Tiles pattern mask
  - **Waves** - Waves pattern mask

- **Custom mask** (image) - Upload or select a custom mask image. Only available when mask is set to "Custom".

- **Size** (select) - How the mask should fit. Options: `auto`, `cover`, `contain`, `custom`. Default: `contain`.

- **Custom size** (number) - Custom mask size with units. Only available when size is set to "custom".

- **Position** (select) - Position of the mask. Options: `center center`, `center left`, `center right`, `top center`, `top left`, `top right`, `bottom center`, `bottom left`, `bottom right`. Default: `center center`.

- **Repeat** (select) - How the mask should repeat. Options: `no-repeat`, `repeat`, `repeat-x`, `repeat-y`, `round`, `space`. Default: `no-repeat`.

> **Developer reference**
>
> See the [Image Schema](https://academy.bricksbuilder.io/developer/schema/elements/image/) for the full JSON schema of this element's settings and controls.

---

# Text basic

Source: https://academy.bricksbuilder.io/builder/elements/basic/text-basic/

*The Basic Text element displays simple text content with basic formatting options. Use this element for paragraphs, small text blocks, or any content that.*

The Basic Text element displays simple text content with basic formatting options. Use this element for paragraphs, small text blocks, or any content that doesn't require rich text formatting.

## Settings

- **Text** (textarea) - The text content to display. Select text on canvas to access the formatting toolbar for styling options like bold, italic, and links. Line breaks are rendered as `<br>` tags.

- **HTML tag** (select) - The HTML tag to wrap the text content. Options: `div`, `p`, `span`, `figcaption`, `address`, `figure`, `custom`. Default: `div`.

- **Custom tag** (text) - Specify a custom HTML tag name without attributes. Only available when HTML tag is set to "custom".

- **Link to** (link) - Make the entire text element clickable by adding a link.

- **Words limit** (number) - Limit the number of words displayed. Minimum value: 1.

- **Read more** (text) - Text to display after the truncated content when using words limit. Only available when words limit is set.

> **Developer reference**
>
> See the [Basic Text Schema](https://academy.bricksbuilder.io/developer/schema/elements/text-basic/) for the full JSON schema of this element's settings and controls.

---

# Text Link

Source: https://academy.bricksbuilder.io/builder/elements/basic/text-link/

*The Text Link element creates a clickable text link with optional icon and advanced styling options.*

The Text Link element creates a clickable text link with optional icon and advanced styling options.

## Settings

- **Text** (text) - The link text to display. Default: "Text link".

- **Link to** (link) - Configure the link URL, target, and attributes.

### Icon

- **Icon** (icon) - Add an icon to the link.

- **Size** (number with units) - Icon size. Only available when an icon is selected.

- **Width** (number with units) - Icon container width. Only available when an icon is selected.

- **Height** (number with units) - Icon container height. Only available when an icon is selected.

- **Color** (color) - Icon color (applies to icon font color and SVG fill). Only available when an icon is selected.

- **Background color** (color) - Icon background color. Only available when an icon is selected.

- **Border** (border) - Icon border styling. Only available when an icon is selected.

- **Position** (select) - Icon placement relative to text. Options: `left`, `right`. Default: `right`. Only available when an icon is selected.

- **Gap** (number with units) - Space between the icon and text. Only available when an icon is selected.

> **Developer reference**
>
> See the [Text Link Schema](https://academy.bricksbuilder.io/developer/schema/elements/text-link/) for the full JSON schema of this element's settings and controls.

---

# Rich text

Source: https://academy.bricksbuilder.io/builder/elements/basic/text/

*The Rich Text element provides a full WYSIWYG editor for creating formatted content with headings, paragraphs, lists, and other rich text elements.*

The Rich Text element provides a full WYSIWYG editor for creating formatted content with headings, paragraphs, lists, and other rich text elements.

## Settings

- **Text** (WYSIWYG editor) - Full rich text editor with support for headings, paragraphs, lists, links, and text formatting.

- **Type** (select) - Predefined text type. Options: `hero`, `lead`. Default: None.

- **Style** (select) - Apply a predefined color style from your theme styles. Default: None.

- **Words limit** (number) - Limit the number of words displayed. Minimum: 1. Handles HTML tags properly when trimming.

- **Read more** (text) - Text to display after the truncated content when using words limit. Only available when words limit is set.

> **Developer reference**
>
> See the [Rich Text Schema](https://academy.bricksbuilder.io/developer/schema/elements/text/) for the full JSON schema of this element's settings and controls.

---

# Video

Source: https://academy.bricksbuilder.io/builder/elements/basic/video/

*The Video element embeds YouTube, Vimeo, or self-hosted videos with support for custom players, preview images, and overlay icons.*

The Video element embeds YouTube, Vimeo, or self-hosted videos with support for custom players, preview images, and overlay icons.

![](https://academy.bricksbuilder.io/assets/bricks-video-element.png)

Source dropdown options:

- YouTube
- Vimeo
- Media
- File URL
- Dynamic Data

## Settings

### Source

- **Source** (select) - The video source type. Options: `youtube`, `vimeo`, `media` (media library), `file` (file URL), `meta` (dynamic data). Default: `youtube`.

- **Iframe title** (text) - Accessible title for the video iframe. Available for YouTube and Vimeo sources.

### YouTube Settings

Available when source is set to "youtube":

- **YouTube video ID/URL** (text) - Enter the YouTube video ID or full URL. Default: `5DGo0AYOJ7s`.

- **Autoplay** (checkbox) - Automatically play the video on page load. Not supported on mobile devices. Not available when preview image is enabled.

- **Controls** (checkbox) - Show video player controls. Default: enabled.

- **Loop** (checkbox) - Loop the video playback.

- **Mute** (checkbox) - Mute the video audio.

- **Related videos from other channels** (checkbox) - Allow YouTube to show related videos from other channels.

- **Do not track** (checkbox) - Use YouTube's privacy-enhanced mode (youtube-nocookie.com).

### Vimeo Settings

Available when source is set to "vimeo":

- **Vimeo video ID/URL** (text) - Enter the Vimeo video ID or full URL.

- **Vimeo privacy hash** (text) - Required for unlisted Vimeo videos.

- **Autoplay** (checkbox) - Automatically play the video on page load. Not available when preview image is enabled.

- **Loop** (checkbox) - Loop the video playback.

- **Mute** (checkbox) - Mute the video audio.

- **Byline** (checkbox) - Show the video byline. Default: enabled.

- **Title** (checkbox) - Show the video title. Default: enabled.

- **User portrait** (checkbox) - Show the user portrait. Default: enabled.

- **Do not track** (checkbox) - Enable Vimeo's Do Not Track feature.

- **Color** (color) - Custom color for Vimeo player controls.

### Preview Image

Available when source is set to "youtube" or "vimeo":

- **Preview image** (select) - Choose preview image source. Options: `default` (API), `custom`. The video iframe is lazy loaded after clicking the preview image.

- **Custom preview image** (image) - Upload/select custom preview image. Only available when preview image is set to "custom".

- **Image size** (select) - YouTube preview image size. Options: `default` (120x90), `medium` (320x180), `high` (480x360), `standard` (640x480), `maximum` (1280x720). Only available for YouTube with default preview image.

### Media/File Settings

Available when source is set to "media", "file", or "meta":

#### Media Source

- **Media** (video) - Upload or select video file from media library. Only available when source is set to "media".

#### File Source

- **Video file URL** (text) - Enter direct URL to video file. Only available when source is set to "file".

#### Dynamic Data Source

- **Dynamic data** (text) - Select dynamic data for video source. Only available when source is set to "meta".

#### Video Controls

- **Preload** (select) - Video preload behavior. Options: `metadata`, `auto`, `none`.

- **Autoplay** (checkbox) - Automatically play the video on page load.

- **Loop** (checkbox) - Loop the video playback.

- **Mute** (checkbox) - Mute the video audio.

- **Play inline** (checkbox) - Play video inline instead of fullscreen on mobile.

- **Controls** (checkbox) - Show video player controls. Default: enabled.

- **Disable download** (checkbox) - Remove download button from controls. Firefox: Not supported.

- **Disable fullscreen** (checkbox) - Remove fullscreen button from controls. Firefox: Not supported.

- **Disable remote playback** (checkbox) - Remove remote playback button from controls. Firefox: Not supported.

- **Poster** (image) - Set poster image for video SEO. Used as preview image for YouTube/Vimeo sources.

### Overlay / Icon

- **Overlay** (background) - Background styling for the video overlay.

- **Icon** (icon) - Select icon to display on the video overlay.

- **aria-label** (text) - Accessibility label for the icon or overlay.

- **Icon typography** (typography) - Typography settings for the icon (size, color).

- **Icon padding** (spacing) - Padding around the icon.

- **Icon background color** (color) - Background color for the icon.

- **Icon border** (border) - Border styling for the icon.

- **Icon box shadow** (box-shadow) - Box shadow for the icon.

## Known Issues

### Perfmatters Plugin Compatibility

Enabling the "YouTube Preview Thumbnails" setting of the Perfmatters plugin might result in an empty space above the YouTube videos. A possible fix is adding the following CSS:

```css
.brxe-video .perfmatters-lazy-youtube {
    margin-top: -56.25%;
}
```

> **Developer reference**
>
> See the [Video Schema](https://academy.bricksbuilder.io/developer/schema/elements/video/) for the full JSON schema of this element's settings and controls.

---

# Filter active filters

Source: https://academy.bricksbuilder.io/builder/elements/filter/filter-active-filters/

*Display selected query filters as removable buttons and exclude filters from the active list.*

Displays the currently active or selected filters, allowing users to easily remove a filter with a single click for faster navigation. This element shows all active filters from the connected target query and provides quick access to clear individual filters.

**Tip:** Use this element alongside other filter elements to give users clear visibility of their current filter selections and easy ways to modify their search criteria.

## Settings

- **Target query** (query-list) - Select the query whose active filters should be displayed.
- **Global filter** (Bricks 2.5) - Reuse the shared behavior of another Active Filters configuration. The target query and styling remain local.
- **Exclude filter IDs** (text) - Enter filter element IDs, separated by commas, to exclude from the active filters list. From Bricks 2.5, accepts global filter IDs too. A linked element's ID excludes its shared filter for the target query.
- **Button** - Settings for the remove filter buttons.
  - **Padding** (spacing) - Padding for filter remove buttons.
  - **Gap** (number) - Gap between filter buttons.
  - **Size** (select) - Button size preset. Options: Default, Small, Medium, Large, Extra Large.
  - **Style** (select) - Button style. Options: None, Primary, Secondary, Success, Info, Warning, Danger, Dark, Light.
  - **Circle** (checkbox) - Make buttons circular.
  - **Outline** (checkbox) - Use outline button style.
  - **Background color** (color) - Custom background color for buttons.
  - **Border** (border) - Border styling for buttons.
  - **Typography** (typography) - Typography settings for button text.
- **Icon** - Settings for filter remove icons.
  - **Icon** (icon) - Icon to display on filter buttons.
  - **Color** (color) - Icon color.
  - **Size** (number) - Icon size.
  - **Gap** (number) - Gap between icon and text.
  - **Position** (select) - Icon position. Options: Left, Right. Default: Right.
- **Active filter** - Settings for active filter display.
  - **Prefix** (text) - Text to display before filter value.
  - **Suffix** (text) - Text to display after filter value.
  - **Title** (text) - Custom title attribute for filter links.

## Default selections

Starting with Bricks 2.5, [configured default values](https://academy.bricksbuilder.io/builder/dynamic-content/query-filters/#default-values) appear as active selections on the first page load. Visitors can remove them like other selections. Removing a default does not immediately reapply it; a fresh visit or reload without filter parameters applies it again. Display exclusions still apply.

## Excluding a Global Filter

Starting with Bricks 2.5, use a [global filter](https://academy.bricksbuilder.io/builder/dynamic-content/query-filters/#global-filters) ID or any linked element's ID in **Exclude filter IDs**. For example, exclude a shared results-per-page filter to keep it out of the active-filter list across desktop and mobile copies. This hides the entry without clearing its selection or changing the query.

Copy a definition ID from Filter manager, or use the Bricks ID from a linked element's panel. Do not use a target query ID or URL parameter name. This display exclusion is separate from a Reset button's exclusions, which preserve values when resetting.

> **Developer reference**
>
> See the [Filter - Active Filters Schema](https://academy.bricksbuilder.io/developer/schema/elements/filter-active-filters/) for the full JSON schema of this element's settings and controls.

---

# Filter checkbox

Source: https://academy.bricksbuilder.io/builder/elements/filter/filter-checkbox/

*Filter query results with multiple selections, include child-term counts, and show collapsible taxonomy branches with Show more/less controls.*

Creates a checkbox filter interface for AJAX-powered content filtering. Users can select multiple options to narrow down query results. Supports taxonomy terms, WordPress fields, and custom fields as filter sources.

For initial setup, see [Query Filters](https://academy.bricksbuilder.io/builder/dynamic-content/query-filters/#setup).

## Settings

- **Target query** (query-list) - Select the post, term, or user query this filter should target. Available sources depend on the query type.
- **URL parameter** (text) - Define a unique, more readable URL parameter name for this filter.
- **Apply on** (select) - Choose when to apply the filter. Options: Input (immediate), Submit (requires button click). Default: Input.
- **Source** (select) - Data source for filter options. Options: Taxonomy, WordPress field, Custom field.
- **Field type** (select) - Type of field when using WordPress field or custom field source. Options: Post, Term, User.
- **Field** (select) - Specific field to filter by (varies based on field type).
- **Taxonomy** (select) - Taxonomy to use for filtering when source is taxonomy.
- **Order by** (select) - How to order taxonomy terms. Options: Name, Slug, Term ID, Description, Parent, Count, Include, Menu Order, Meta Value, Meta Value Num.
- **Order meta key** (text) - Meta key for ordering when using meta value ordering.
- **Order** (select) - Sort direction. Options: ASC, DESC. Default: ASC.
- **Terms: Include** (select) - Specific taxonomy terms to include in filter options.
- **Terms: Exclude** (select) - Specific taxonomy terms to exclude from filter options.
- **Top level terms only** (checkbox) - Display only top-level terms (parent = 0) when source is taxonomy.
- **Hide count** (checkbox) - Hide the result count for each option.
- **Count: Include children** (checkbox, Bricks 2.5) - Include descendant-term posts in parent taxonomy counts. Off by default. Requires a target query and a selected taxonomy. See [taxonomy child counts](https://academy.bricksbuilder.io/builder/dynamic-content/query-filters/#taxonomy-child-counts).
- **Hide empty** (checkbox) - Hide options with zero results.
- **Hide count bracket** (checkbox) - Remove brackets around count values. Style count via .brx-option-count.
- **Provider** (select) - Custom field provider for integration (ACF, Meta Box, etc.).
- **Meta key** (text) - Custom field key for filtering.
- **Compare** (select) - Comparison operator for filtering. Options: IN, NOT IN, BETWEEN, NOT BETWEEN.
- **Mode** (select) - Display mode for checkboxes. Options: Default (traditional checkboxes), Button (modern button style).
- **Active filter** - Settings for active filter display.
  - **Prefix** (text) - Text to display before filter value.
  - **Suffix** (text) - Text to display after filter value.
  - **Title** (text) - Custom title attribute for filter links.

## Collapsible Taxonomy Branches {#collapsible-hierarchy}

Starting with **Bricks 2.5**, visitors can expand and collapse child branches in a hierarchical taxonomy Checkbox filter. This is useful for category lists where showing every nested term would make the filter too long.

1. Set **Target query**, choose **Taxonomy** as the source, and select a taxonomy with parent and child terms.
2. Open the **Hierarchy** control group and enable **Hierarchical**.
3. Turn on **Enable expand/collapse**.
4. Leave **Show expanded** off to start with branches collapsed, or enable it to show all branches expanded initially.
5. Save and check the frontend. Parent terms with visible children have a separate expand/collapse button beside the checkbox.

| Hierarchy setting | Behavior |
| --- | --- |
| Hierarchical | Arrange taxonomy terms under their parents. |
| Auto toggle child terms | Toggle child checkboxes when a parent checkbox changes. This is separate from expanding a branch. |
| Enable expand/collapse | Add buttons to open and close child branches. Off by default. |
| Show expanded | Expand all branches initially. Off by default. |
| Expand icon / Collapse icon | Choose the disclosure icons. Defaults are plus and minus. |
| Icon typography / Icon gap | Set the icon appearance and spacing. |
| Indent: Prefix / Indent: Gap | Set child-term indentation in the default display mode. |

The disclosure button opens or closes a branch without selecting its checkbox. Visitors can focus the button and use Enter or Space to toggle it. Selected child terms open their ancestor branches on page load, including selections loaded from URL parameters. Bricks preserves each element's expanded branches through AJAX updates and opens the path to selected terms when needed.

Only terms present in the filter's options can appear in a branch. **Top level terms only**, term exclusions, and **Hide empty** can remove child options. If a parent has no visible children, it has no expand/collapse button. Use [Count: Include children](https://academy.bricksbuilder.io/builder/dynamic-content/query-filters/#taxonomy-child-counts) if parent counts should include posts assigned to descendants.

<div className="screenshot screenshot--control-panel">

![Hierarchy settings with expand/collapse enabled, Show expanded off, and plus and minus icons selected.](https://academy.bricksbuilder.io/assets/filter-checkbox-hierarchy-settings.webp)

</div>

### Show More/Less With Branches {#show-more-less}

In the **Show more / Show less** control group, set **Visible options limit** to limit the initial list. Leave it empty to show all options.

When **Enable expand/collapse** is on, this limit counts whole root branches, not individual child terms. For example, a limit of three shows the first three root branches. Expanding one of them reveals its children without using up another place in the limit. **Show more** reveals the remaining root branches; **Show less** returns to the initial limit.

A branch containing a selected term stays visible even beyond the limit, so the list can show more than the configured number of roots. **Show more: Text** accepts `%number%` for the number of hidden root branches. In the collapsed list, the Show more button is hidden when no additional branches remain hidden. Without expand/collapse, the limit counts individual options.

![The Hoodies child term remains visible under Clothing beyond the two-branch limit, with Show 1 more available and three matching products.](https://academy.bricksbuilder.io/assets/filter-checkbox-collapsible-branches.webp)

### Linked Desktop and Mobile Filters {#linked-hierarchies}

When using a [global filter](https://academy.bricksbuilder.io/builder/dynamic-content/global-filters-filter-manager/), **Hierarchical**, **Auto toggle child terms**, and **Count: Include children** are shared settings. Expand/collapse, Show expanded, icons, indentation, and Show more/less limits stay on each element.

Linked elements targeting the same query synchronize their checkbox selections. Each copy keeps its own expanded branches and Show more/less state, so a mobile filter can start collapsed while the desktop copy starts expanded.

## Default selection {#default-selection}

Starting with **Bricks 2.5**, this filter can apply a selection before the first query runs. Use **Default value** to preselect exact option values, separated by commas, such as `cotton, wool`. Use taxonomy slugs or raw stored values rather than display labels. Wrap a value containing a comma in double quotes. Dynamic data is supported.

<div className="screenshot screenshot--control-panel">

![A Checkbox filter's Default value set to cotton, wool.](https://academy.bricksbuilder.io/assets/query-filter-default-values.webp)

</div>

The default applies even with **Apply on** set to **Submit**. Filter URL selections take precedence, and **Reset** clears the selection instead of restoring the default. A fresh visit or reload without filter parameters applies it again. See [default filter values](https://academy.bricksbuilder.io/builder/dynamic-content/query-filters/#default-values) for shared defaults, validation, and URL behavior.

> **Developer reference**
>
> See the [Filter - Checkbox Schema](https://academy.bricksbuilder.io/developer/schema/elements/filter-checkbox/) for the full JSON schema of this element's settings and controls.

---

# Filter datepicker

Source: https://academy.bricksbuilder.io/builder/elements/filter/filter-datepicker/

*Filter query results by a single date or date range, including events stored with separate start and end date fields.*

Use Filter - Datepicker to filter a Query Loop by post dates, user registration dates, or custom date fields. Visitors can select a single date or a date range, with optional time selection.

Enable [Query Filters](https://academy.bricksbuilder.io/builder/dynamic-content/query-filters/#enable), add the element, and select its **Target query**. Starting with **Bricks 2.5**, date ranges can use separate start and end custom fields on posts, terms, or users, including supported ACF, Meta Box, and JetEngine fields.

## Settings

- **Target query** (query-list) - Select the Posts, Terms, or Users query this filter should target.
- **URL parameter** (text) - Define a unique, more readable URL parameter name for this filter.
- **Apply on** (select) - Choose when to apply the filter. Options: Input (immediate), Submit (requires button click). Default: Input.
- **Source** (select) - Data source for filter options. Options: WordPress field, Custom field.
- **Field type** (select) - Type of field when using WordPress field or custom field source. Options: Post, Term, User.
- **Field** (select) - Specific date field to filter by (post date, modified date, user registered date).
- **Provider** (select) - Custom field provider for integration (ACF, Meta Box, etc.).
- **Meta key** (text) - Custom field containing date values. For separate start and end fields, this is the start field. Enter a native meta key or use the selected provider's field picker.
- **End date meta key** (text, Bricks 2.5) - Optional separate end-date field from the same provider and object type as **Meta key**. Leave empty to compare both selected dates against **Meta key**. See [separate start and end fields](#separate-date-fields).
- **Enable time** (checkbox) - Add time selection capability to the date picker.
- **Date range** (checkbox) - Enable selection of date ranges instead of single dates.
- **Min/max date** (checkbox) - Use minimum and maximum dates from the index table for date picker limits.
- **Compare** (select) - Comparison operator for single-date filtering. Options: == (is), < (before), > (after).
- **Input** - Settings for the date input field.
  - **Placeholder** (text) - Placeholder text for the input field. Default: Date.
  - **Placeholder typography** (typography) - Typography for placeholder text.
  - **Language** (text) - Language code for date picker localization (de, es, fr, etc.).
  - **Datepicker format** (text) - Display format, defaulting to `Y-m-d`. **Enable time** appends `H:i`. This does not change how dates are stored in the database.
- **Active filter** - Settings for active filter display.
  - **Prefix** (text) - Text to display before filter value.
  - **Suffix** (text) - Text to display after filter value.
  - **Title** (text) - Custom title attribute for filter links.

## Separate start and end fields {#separate-date-fields}

Use **End date meta key** when each item in a Posts, Terms, or Users query stores its start and end dates in separate custom fields.

1. Set **Target query** to the results loop.
2. Set **Source** to **Custom field** and **Field type** to the objects in that loop: **Post**, **Term**, or **User**.
3. For native metadata, leave **Provider** at **WordPress**. For ACF, Meta Box, or JetEngine, enable [Custom fields integration](https://academy.bricksbuilder.io/builder/dynamic-content/query-filters/#custom-fields-integration) and select the provider.
4. In **Meta key**, enter the native start field's key, such as `event_start`, or select the provider field using the dynamic data picker.
5. Enable **Date range**.
6. In **End date meta key**, enter the native end field's key, such as `event_end`, or use its picker to select the provider field.
7. Optionally enable **Min/max date** to limit the calendar to the indexed date bounds.
8. Save the builder and allow indexing to finish before testing the frontend.

For native metadata, enter literal keys without dynamic data braces. For provider fields, use the picker on each control. Bricks reads the selected field's definition; these references are not frontend dynamic data output. Both fields must belong to the same provider and object type, with compatible post type or taxonomy locations.

<div className="screenshot screenshot--control-panel">

![Datepicker controls using Post fields and ACF, with departure_date as the start field, return_date as the end field, and Date range and Min/max date enabled.](https://academy.bricksbuilder.io/assets/datepicker-acf-separate-date-fields.webp)

</div>

### Supported fields and storage {#supported-date-fields}

Each field must store one date or datetime value per object. These sources support field pairs on posts, terms, and users:

| Source | Supported date fields |
| --- | --- |
| WordPress metadata | Date strings such as `2027-03-09` or `20270309`, and ISO datetime strings such as `2027-03-09 10:00:00`. |
| ACF | Date Picker and Date Time Picker, including scalar fields inside ordinary Group fields. |
| Meta Box | Date and Datetime fields stored in native WordPress metadata, including numeric save formats such as `d/m/Y H:i:s` and timestamp storage. User and term fields require the corresponding Meta Box extensions. |
| JetEngine | Date and Datetime fields stored in native WordPress metadata, as strings or timestamps. |

Bricks resolves each field's storage separately. The start and end fields can use different supported formats or timestamp settings. ACF's Date Picker stores `Ymd` values; changing its return format or **Datepicker format** does not change how Bricks compares the stored dates.

Time-only fields, repeating or cloneable fields, serialized groups, and custom-table storage are not supported for separate start and end fields. The provider pickers limit choices to compatible date fields. ACF Group fields are supported only where each date is stored as its own metadata value, rather than inside a repeated or serialized structure.

If a provider is unavailable or a selected field is deleted or incompatible, Bricks reports a configuration error. Select a compatible replacement or clear **End date meta key** to return to one-field behavior. An invalid pair does not silently compare the start field twice.

### Example: ACF dates on taxonomy terms

If each term in an event taxonomy has ACF `event_start` and `event_end` Date Picker fields, target the **Terms** loop and set **Field type** to **Term** and **Provider** to **ACF**. Select `event_start` in **Meta key**, enable **Date range**, and select `event_end` in **End date meta key**. Both ACF fields must be available on the taxonomy being queried.

### Which events match?

Both conditions must be met:

- The event starts on or after the selected start date.
- The event ends on or before the selected end date.

For a selected range of **March 8–10, 2027**, with **Enable time** off:

| Event dates | Included? |
| --- | --- |
| March 8–10 | Yes, both boundaries are included. |
| March 9 | Yes, the event fits within the range. |
| March 9–12 | No, it ends after March 10. |
| March 7–9 | No, it starts before March 8. |

An event must fit entirely within the selection. An event that overlaps only part of the range is excluded. Both date fields must contain valid values, and the stored start must not be later than the stored end. Items with missing, empty, invalid, or reversed dates are excluded from filtered results and calendar bounds.

With **Enable time** off, the selection covers complete days, including the whole final day. With it on, the selected hours and minutes are part of the comparisons, and the final minute includes seconds through `:59`. A stored end field containing only a date represents the end of that day.

Select both endpoints to apply a range; selecting only the first date does not filter the query. Choose the same day for both endpoints to filter a single day. The range narrows the query's existing restrictions, including groups of conditions joined by **OR**.

Leave **End date meta key** empty to filter one field between the selected dates. Turning off **Date range** uses **Meta key** and the **Compare** setting; the separate end field is ignored.

Changing **Source**, **Provider**, or **Field type** clears the retained end-field selection. Select a compatible end field again after the change. The **WordPress field** source, such as Post date or User registered date, keeps its existing single-field behavior.

### Calendar limits and indexing

With a separate end field configured, Bricks indexes both dates from complete, valid intervals. **Min/max date** uses those indexed values, so a multi-day event's end date can extend the calendar's upper limit. It does not disable individual days without events inside those limits or select a particular opening month.

Adding, updating, or deleting either date field refreshes the affected post, term, or user's complete interval through the normal queue. If either value is removed or becomes invalid, neither date from that item contributes to the bounds. Upgrades and changes to the selected field definitions can queue an index rebuild. If the calendar limits appear stale, check the [filter indexing tools](https://academy.bricksbuilder.io/builder/dynamic-content/query-filters/#filter-index) and allow pending jobs to finish.

### Shared Datepicker settings

When using a [Global Filter](https://academy.bricksbuilder.io/builder/dynamic-content/global-filters-filter-manager/), the provider, field type, and both field selections belong to the shared configuration. Linked Datepickers use those fields and one shared index while keeping their own target queries and styling. Linking to a global filter without an end key uses one-field behavior, even if the element previously had a local end key.

## Default selection {#default-selection}

Starting with **Bricks 2.5**, this filter can apply a selection before the first query runs. For a single date, enter **Default value** in `YYYY-MM-DD` format. With **Date range** enabled, provide both **Start date** and **End date** in that format, with the start no later than the end. These fields support dynamic data, which must return the same format regardless of the display or stored field format.

The default applies even with **Apply on** set to **Submit**. Filter URL selections take precedence, and **Reset** clears the selection instead of restoring the default. A fresh visit or reload without filter parameters applies it again. See [default filter values](https://academy.bricksbuilder.io/builder/dynamic-content/query-filters/#default-values) for shared defaults, validation, and URL behavior.

> **Developer reference**
>
> See the [Filter - Datepicker Schema](https://academy.bricksbuilder.io/developer/schema/elements/filter-datepicker/) for the full JSON schema of this element's settings and controls.

---

# Filter Geolocation

Source: https://academy.bricksbuilder.io/builder/elements/filter/filter-geolocation/

*Filter posts, terms, or users by distance from an address, device location, or map center, and show nearby results on Google Maps or Leaflet.*

The **Filter - Geolocation** element, available in **Bricks 2.5**, finds results within a radius of a selected location. Use it for store locators, property listings, or directories where visitors need to find nearby places.

Visitors can search from an address, their device location, or the center of a connected map. A map is optional. The filter supports native **Posts**, **Terms**, and **Users** query loops.

Distance is measured along the earth's surface in a straight line, not along roads. It does not represent driving distance or travel time.

## Basic setup {#setup}

1. Enable **Enable query sort / filter / live search** under **Bricks > Settings > Query filters**.
2. Create a [Query Loop](https://academy.bricksbuilder.io/builder/dynamic-content/query-loop/) for your listing.
3. Add **Filter - Geolocation** from the **Filter** element group.
4. Set **Target query** to the listing's loop.
5. Under **Data source**, set **Object type** to **Post**, **Term**, or **User** to match the listing, then configure its [coordinate fields](#coordinates).
6. Enable **Search by address**, **Search by device location**, or both. Both are off by default.
7. Set the radius and distance unit. Enable **Radius dropdown** if visitors should choose the radius.
8. Save the builder and let indexing finish. Test the search on the frontend.

For example, a store directory can use a Posts query with `store_latitude` and `store_longitude` custom fields. Enable device-location search and offer 5, 10, 25, and 50 km radii. A visitor selects their location and 25 km, and the listing shows stores within that distance.

![A 25 km device-location search around Johor Bahru, with a removable active-filter label, a result showing its distance, and a Leaflet map showing the origin and radius.](https://academy.bricksbuilder.io/assets/academy-filter-geolocation-leaflet.webp)

## Coordinate fields {#coordinates}

Every result needs saved latitude and longitude values. Bricks indexes these coordinates for distance searches. It does not convert saved street addresses into coordinates during indexing.

### WordPress meta fields

Use the **WordPress** provider, or the native coordinate controls when custom-field integration is disabled.

| Coordinate format | Settings | Example saved values |
| --- | --- | --- |
| **Separate fields** (default) | **Latitude meta key** and **Longitude meta key** | `store_latitude`: `1.4927`; `store_longitude`: `103.7414` |
| **Combined field** | **Coordinates meta key** | `store_coordinates`: `1.4927,103.7414` |

Enter the meta key names, not dynamic data tags. For combined fields, latitude comes first. Bricks reads post, term, or user metadata according to **Object type**.

Latitude must be between -90 and 90, and longitude between -180 and 180. Missing or invalid coordinates are excluded from location searches. An item can appear in the unfiltered listing and disappear when a radius search is applied if its coordinates are missing.

### ACF and Meta Box map fields

1. Enable **Custom fields integration** under **Bricks > Settings > Query filters**.
2. Set **Provider** to **ACF** or **Meta Box** on the Geolocation filter.
3. Open the dynamic data picker in **Location field** and select an **ACF Google Map** or **Meta Box Map** field.

These integrations read the saved coordinates from the map field. The provider choices for this element are limited to ACF and Meta Box, even when other query-filter integrations are active.

After importing locations or changing the coordinate source, use **Regenerate filter index** under **Bricks > Settings > Query filters** if results are missing or outdated. See [Filter Index](https://academy.bricksbuilder.io/builder/dynamic-content/query-filters/#filter-index) for background indexing controls.

### Coordinates from a custom storage format {#custom-coordinate-storage}

For integrations that store coordinates in another format, use the `bricks/query_filters/geolocation/coordinates` PHP filter. It runs while Bricks indexes each object, after the normal coordinate lookup, rather than on every visitor search.

The callback receives five arguments:

| Argument | Value |
| --- | --- |
| `$coordinates` | The resolved `['lat' => ..., 'lng' => ...]` array, or `false` when no valid coordinates were found. |
| `$object_id` | The post, term, or user ID being indexed. |
| `$object_type` | `post`, `term`, or `user`. |
| `$settings` | The Geolocation filter settings used for indexing. |
| `$filter_id` | The filter ID that owns the coordinate index. |

For example, suppose a `store` post type saves an array under `_directory_location`, with `latitude` and `longitude` keys. Configure the Geolocation filter with **Object type > Post**, **Combined field**, and **Coordinates meta key** set to `_directory_location`. Add this callback to your child theme or a custom plugin:

```php
add_filter( 'bricks/query_filters/geolocation/coordinates', function ( $coordinates, $object_id, $object_type, $settings, $filter_id ) {
    if (
        $object_type !== 'post' ||
        get_post_type( $object_id ) !== 'store' ||
        ( $settings['geoCoordinateSource'] ?? 'separate' ) !== 'combined' ||
        ( $settings['geoCoordinatesKey'] ?? '' ) !== '_directory_location'
    ) {
        return $coordinates;
    }

    $location = get_post_meta( $object_id, '_directory_location', true );

    if ( ! is_array( $location ) ) {
        return false;
    }

    return [
        'lat' => $location['latitude'] ?? null,
        'lng' => $location['longitude'] ?? null,
    ];
}, 20, 5 );
```

The scope checks preserve other filters and object types. Return the incoming value when your integration does not apply, or `false` to exclude that object's coordinates. Bricks validates the returned array again: latitude and longitude must be finite numbers within the ranges above. An invalid result is not indexed, and stale coordinates for that object are removed during reindexing.

After adding the callback or changing its stored data, [regenerate the filter index](https://academy.bricksbuilder.io/builder/dynamic-content/query-filters/#filter-index) to update existing results. Integrations can also [request a rebuild from PHP](https://academy.bricksbuilder.io/developer/hooks/actions/bricks-query_filters-reindex/#request).

## Search methods {#search-methods}

### Address search

Enable **Search by address** to display an address field and Search button. Save a Google Maps API key under **Bricks > Settings > API keys**. The key needs access to **Maps JavaScript API** and **Geocoding API**, with billing and website restrictions configured for your site. Saving a key does not verify access to those services.

**Address autocomplete** adds suggestions while typing and additionally requires **Places API (New)**. If suggestions fail, visitors can still type an address and use Search. See [Google Maps API key setup](https://academy.bricksbuilder.io/integrations/how-to-set-up-your-google-maps-api-key/#geolocation).

- **Country codes** limits suggestions to up to 15 two-letter country codes, separated by commas or spaces. Leave it empty for all countries.
- **Autocomplete map area** can **Prefer map area** (default), **Limit to map area**, or **Ignore map area** when a map is connected.
- **Hide label** hides the address label visually while retaining its accessible name.
- **Hide search button** leaves Enter available to run a search.

Autocomplete restrictions affect address suggestions. The selected origin and radius determine which listing items match.

### Device-location search

Enable **Search by device location** to display a location button. Choose text, an icon, or both, and configure the enabled and clear states under **Device location button**.

Bricks requests location permission only after the visitor activates the button. The browser must support geolocation and permit it on the site, normally over HTTPS. If permission is denied or the location cannot be retrieved, the previous applied search remains in place.

Device-location search does not need a Google Maps API key. It works with a listing alone or a connected Leaflet map without Google services. Enabling address search still requires the Google APIs, including when the connected map uses Leaflet.

## Default location {#default-location}

Enable **Use default location** to apply a radius search before the first query runs. This works with Google Maps, Leaflet, or a listing without a map.

1. Set **Target query** and enable at least one visitor search method: **Search by address** or **Search by device location**.
2. Under **Default location**, enable **Use default location**.
3. Enter **Latitude** and **Longitude**, for example `3.1390` and `101.6869` for Kuala Lumpur.
4. Optionally enter a **Location label**, such as "Kuala Lumpur". An empty label displays "Default location".
5. Set **Default radius** and **Distance unit**, for example 25 km, then save and test a URL without filter parameters.

<div className="screenshot screenshot--control-panel">

![Use default location enabled with latitude 3.1390, longitude 101.6869, and Kuala Lumpur as the location label.](https://academy.bricksbuilder.io/assets/query-filter-default-location.webp)

</div>

Latitude, longitude, and label support dynamic data from the original page or template preview context. Coordinates must resolve to valid numbers. The label is display text, not an address that Bricks needs to geocode. It appears in Active Filters and the address input when address search is enabled. Submitting the unchanged label uses the existing coordinates.

The default applies immediately, including with **Apply on** set to **On submit**. It uses the configured radius and unit, does not derive coordinates from the map center, and does not request the visitor's device location. Device access still requires the visitor to activate its button.

Use one default location per target query. Duplicate desktop and mobile controls can share a default through one [global filter](https://academy.bricksbuilder.io/builder/dynamic-content/global-filters-filter-manager/). If independent Geolocation filters targeting the same query each define a valid default location, Bricks skips those defaults and shows a warning in the builder preview. Invalid or incomplete coordinates are also skipped.

Recognized filter URL parameters take precedence over defaults. **Reset** clears the location; a fresh visit or reload without filter parameters applies it again. Defaults are not reapplied during AJAX updates, pagination, or browser Back/Forward. Coordinates enter the URL only when **Save location in URL** is enabled. See [default filter state](https://academy.bricksbuilder.io/builder/dynamic-content/query-filters/#default-state).

## Radius and sorting {#radius}

| Setting | Behavior |
| --- | --- |
| **Default radius** | Uses 5 by default. With a radius dropdown, choose a value from **Radius options**; otherwise Bricks uses the first valid option. Without a dropdown, this is the fixed search radius. |
| **Distance unit** | **Kilometres (km)** by default, or **Miles (mi)**. |
| **Radius dropdown** | Off by default. Lets visitors select one configured radius. Default presets are 5, 10, 25, and 50. Each row has a numeric **Radius** and an **Option label**. |
| **Unit label format** | **Abbreviated (km/mi)** by default, **Full text**, or **Disable**. Applies to the radius options and Active Filters label. Disable it when your option labels already contain their units. |
| **Sort results by distance** | On by default. Shows nearest matches first while the filter is active. An active Sort filter takes precedence without removing the radius constraint. |

Radius changes need an origin before they can filter results. Existing taxonomy, custom-field, search, and other query restrictions still apply. Pagination totals reflect the filtered results.

Under **Radius dropdown**, enable **Enhanced radius dropdown** for Choices.js styling. It remains a single-selection control with a valid radius required.

### Let visitors choose the distance order {#distance-sorting}

Add a [Select](https://academy.bricksbuilder.io/builder/elements/filter/filter-select/) or [Radio](https://academy.bricksbuilder.io/builder/elements/filter/filter-radio/) filter targeting the same query and set **Action** to **Sort**. In **Sort options**, set **Source** to **Distance** and choose **Ascending** for nearest first or **Descending** for farthest first. Give each option a label visitors can recognize.

Distance uses the Geolocation search, including a configured default location. It retains the radius when visitors change sort options and works even when this element's **Sort results by distance** is off. A farthest-first 25 km search still excludes results outside 25 km.

On the frontend, Distance options stay visible but disabled without a valid location for the same query. A valid location enables them even when no results match. Choosing a sort option never requests device location; visitors obtain their location through this element's search controls.

See [Distance sorting setup](https://academy.bricksbuilder.io/builder/dynamic-content/query-filters/#distance-sorting) for the complete configuration.

## When a search applies {#apply-mode}

The Geolocation filter uses **Immediately** and **On submit** labels under **Apply on**.

| Action | Immediately (default) | On submit |
| --- | --- | --- |
| Select an address suggestion or resolve device location | Applies the selected location | Stages the location until a search is submitted |
| Change the radius or pan a map with map search enabled | Applies the change | Stages the change |
| Use the address Search button or press Enter to search | Resolves and applies this location alongside already applied filters | Resolves and applies this location alongside already applied filters |
| Activate a Filter - Submit targeting the same query | Applies all pending filters | Applies all pending filters |

When Enter selects an autocomplete suggestion, that keypress only selects it. Press Enter again to search. In **Immediately** mode, selecting the suggestion can already trigger the update.

In **On submit** mode, device-only setups need a [Filter - Submit](https://academy.bricksbuilder.io/builder/elements/filter/filter-submit/) element targeting the same query. Keep status messages visible so visitors can tell when a location is waiting to be applied.

To apply a pending location and Distance sorting together, set the Select or Radio sort filter's **Apply on** to **Submit** too. A resolved pending location enables its Distance options before submission. Clearing the pending location disables them and clears the pending Distance choice. Use Filter - Submit to apply both changes together.

While a new location is pending, the visible results, distances, active-filter label, and map radius still describe the applied search. They update when the matching results arrive. Failed lookups or requests preserve the previous applied location and results.

## Connect a map {#map}

1. Add a [Map Connector](https://academy.bricksbuilder.io/builder/elements/general/map-connector/) inside the results loop and give it location data for each item. Use coordinates matching the filter's indexed location.
2. Add a [Google Map](https://academy.bricksbuilder.io/builder/elements/general/map/#3-sync-with-query) in JavaScript API render mode, or [Map (Leaflet)](https://academy.bricksbuilder.io/builder/elements/general/map-leaflet/#sync-with-query).
3. Set the map's **Sync with query** to the same results loop targeted by the filter.
4. If exactly one Geolocation filter and one matching map use that query, Bricks connects them automatically. Otherwise, select the intended map under **Map (Optional)** on the filter.

Each Geolocation filter connects to at most one map, and each map to at most one Geolocation filter. Static maps and a map's internal query are not supported filter targets. Leaflet Map Connectors require latitude and longitude.

The map shows the search origin and radius, with markers for the current results. The applied origin and radius stay visible when no results match. Under **Map appearance**, customize the circle's fill and border, origin marker color, or a custom origin marker image.

### Search on map drag

Enable **Search on map drag** on the filter and allow dragging on the connected map. The map center becomes the search origin after the visitor stops panning.

- **Visitor controlled** (default) shows a **Search as I move the map** checkbox. Configure its label, corner position, and **Checked by default** state.
- **Automatic** searches after every qualifying drag without displaying the checkbox.
- **Search delay (ms)** waits after the map settles, using 400 ms by default.

Zooming alone and programmatic map movements do not start a search. **Apply on** still controls whether map changes apply immediately or wait for submission.

## Show the distance in each result {#distance}

Place the following tag in a text element inside the filtered Posts, Terms, or Users loop:

```text
{filter_geo_distance}
```

It shows the current item's distance from the applied origin, using the filter's unit and unit-label format with one decimal place by default. It also works in AJAX-rendered map Info Boxes for those results.

| Argument | Use |
| --- | --- |
| `@to:'km'` or `@to:'mi'` | Convert the displayed distance without changing the search radius. |
| `@decimals:'0'` through `@decimals:'6'` | Set the number of decimal places. |
| `@output:'value'` | Return the rounded numeric value only. |
| `@output:'unit'` | Return the unit label only. |
| `@fallback:'Select a location'` | Show fallback text when no distance is available. |

For example:

```text
{filter_geo_distance @to:'mi' @decimals:'2'}
{filter_geo_distance @fallback:'Select a location'}
```

Without a fallback, the tag returns nothing before a location search is applied or outside a supported filtered loop. API, Array, and provider-specific query loops do not support this tag or Geolocation filtering.

## Active filters and URL state {#state}

An [Active Filters](https://academy.bricksbuilder.io/builder/elements/filter/filter-active-filters/) element shows the location and radius as one removable item. Clear, Reset, and removing that item clear the location search. Applying another independent Geolocation filter to the same query replaces the previous location constraint.

Clearing the location also clears a selected Distance sort and restores the query's normal ordering. Results and URL history update together after the request succeeds. Failed or cancelled requests preserve the last applied results and ordering. Distance options remain configured so they can be enabled for another valid location.

**Save location in URL** is off by default. Enable it if searches should survive a reload or be shareable. It writes the selected coordinates to the page URL and browser history. **URL parameter** changes the parameter name. Browser Back and Forward can restore saved searches.

Geolocation filters support [Global Filters](https://academy.bricksbuilder.io/builder/dynamic-content/global-filters-filter-manager/). Shared behavior includes the coordinate source, search methods, default location, radius, and apply mode. Target query, map connection, and presentation remain local to each linked element.

## Styling and status messages {#styling}

The element has separate control groups for **Layout**, **Label**, **Address**, **Search button**, **Radius dropdown**, **Device location button**, and **Status**. Use these to style the controls at each breakpoint.

Under **Status**, override the pending, loading, success, and error messages. Empty values retain the translated defaults. **Hide status messages** hides them visually while keeping screen reader announcements. It does not hide the separate address-autocomplete fallback notice.

## Troubleshooting {#troubleshooting}

- **No controls appear:** Enable an address or device-location search method. Both are off on a new element.
- **Known locations are missing:** Check the object type, meta keys or provider field, coordinate order and ranges, and filter-index progress. Address-only values cannot be indexed as coordinates.
- **Address search fails:** Check the saved Google key, billing, enabled APIs, and website/API restrictions. Autocomplete needs Places API (New) in addition to the manual-search APIs.
- **Location selected but results have not changed:** Check **Apply on**. Use Search, Enter, or a Filter Submit in **On submit** mode.
- **Map does not connect:** Target the results loop, set the map's **Sync with query** to it, and select the map explicitly if the layout contains multiple filters or maps.
- **Dragging does not search:** Enable map dragging and **Search on map drag**, then check the visitor checkbox and apply mode.

---

# Filter radio

Source: https://academy.bricksbuilder.io/builder/elements/filter/filter-radio/

*Use radio buttons for single-selection query filters, sorting, or results per page, with optional child-term counts for taxonomy filters.*

Creates a radio button filter interface for single-selection filtering. Users can select one option at a time to filter query results. Supports taxonomy terms, WordPress fields, custom fields, and can also function as a sorting or results-per-page control.

Use radio buttons when visitors should select only one option. Set **Action** to **Sort** or **Results per page** when the control should change ordering or page size.

## Settings

- **Target query** (query-list) - Select the post, term, or user query this filter should target. Available sources depend on the query type.
- **URL parameter** (text) - Define a unique, more readable URL parameter name for this filter.
- **Apply on** (select) - Choose when to apply the filter. Options: Input (immediate), Submit (requires button click). Default: Input.
- **Action** (select) - Filter behavior. Options: Filter (traditional filtering), Sort (sorting control), Results per page (pagination control).
- **Source** (select) - Data source for filter options. Options: Taxonomy, WordPress field, Custom field.
- **Field type** (select) - Type of field when using WordPress field or custom field source. Options: Post, Term, User.
- **Field** (select) - Specific field to filter/sort by (varies based on field type and action).
- **Taxonomy** (select) - Taxonomy to use for filtering when source is taxonomy.
- **Order by** (select) - How to order taxonomy terms. Options: Name, Slug, Term ID, Description, Parent, Count, Include, Menu Order, Meta Value, Meta Value Num.
- **Order meta key** (text) - Meta key for ordering when using meta value ordering.
- **Order** (select) - Sort direction. Options: ASC, DESC. Default: ASC.
- **Terms: Include** (select) - Specific taxonomy terms to include in filter options.
- **Terms: Exclude** (select) - Specific taxonomy terms to exclude from filter options.
- **Top level terms only** (checkbox) - Display only top-level terms (parent = 0) when source is taxonomy.
- **Hide count** (checkbox) - Hide the result count for each option.
- **Count: Include children** (checkbox, Bricks 2.5) - Include descendant-term posts in parent taxonomy counts. Off by default. Available with Action set to Filter, a target query, and a selected taxonomy.
- **Hide empty** (checkbox) - Hide options with zero results.
- **Hide count bracket** (checkbox) - Remove brackets around count values. Style count via .brx-option-count.
- **Hierarchical** (checkbox) - Display taxonomy terms in hierarchical structure.
- **Indent: Prefix** (text) - Prefix text for hierarchical indentation. Default: —.
- **Indent: Gap** (number) - Gap spacing for hierarchical indentation.
- **Provider** (select) - Custom field provider for integration (ACF, Meta Box, etc.).
- **Meta key** (text) - Custom field key for filtering.
- **Compare** (select) - Comparison operator for filtering. Default: Equal.
- **Mode** (select) - Display mode for radio buttons. Options: Default (traditional radio buttons), Button (modern button style).
- **Sort options** (repeater) - Configure sorting options when Action is set to Sort.
  - **Source** (select) - Sort field, including **Distance** in Bricks 2.5.
  - **Label** (text) - Display label for the sort option.
  - **Order** (select) - Ascending or Descending. For Distance, nearest first or farthest first.
  - **Meta key** (text) - Meta key for meta-based sorting.
- **Results per page options** (text) - Comma-separated list of results per page options when Action is set to Results per page. Default: 10, 20, 50, 100.
- **Active filter** - Settings for active filter display.
  - **Prefix** (text) - Text to display before filter value.
  - **Suffix** (text) - Text to display after filter value.
  - **Title** (text) - Custom title attribute for filter links.

## Parent-Term Counts {#parent-term-counts}

Enable **Count: Include children** when a parent option should count posts assigned to its child terms and deeper descendants. Posts assigned to both a parent and a descendant count once for the parent. The setting works independently of **Hierarchical** display and is shared when the element uses a global filter. See [taxonomy child counts](https://academy.bricksbuilder.io/builder/dynamic-content/query-filters/#taxonomy-child-counts) for setup, indexing, and an example.

## Default selection {#default-selection}

Starting with **Bricks 2.5**, this filter can apply a selection before the first query runs. Use **Default value** for one exact option value. For the Sort action, enter a configured sort value such as `title_ASC` or `distance_ASC`; for Results per page, enter a configured page size such as `20`. Dynamic data is supported.

A Distance default such as `distance_ASC` also requires a valid location from a Geolocation filter targeting the same query. Without one, Bricks clears the Distance selection and uses the query's normal order.

The default applies even with **Apply on** set to **Submit**. Filter URL selections take precedence, and **Reset** clears the selection instead of restoring the default. A fresh visit or reload without filter parameters applies it again. See [default filter values](https://academy.bricksbuilder.io/builder/dynamic-content/query-filters/#default-values) for shared defaults, validation, and URL behavior.

## Distance sorting {#distance-sorting}

Starting with **Bricks 2.5**, set **Action** to **Sort** and add **Distance** as a sort option's **Source**. Set **Order** to **Ascending** for nearest first or **Descending** for farthest first, and give the option a descriptive **Label**.

A [Geolocation filter](https://academy.bricksbuilder.io/builder/elements/filter/filter-geolocation/) must target the same query and provide a valid location, including a default location. Sorting keeps its radius constraint.

Distance options remain visible but disabled without a valid location. A valid location enables them even when no results match. Clearing the location also clears a selected Distance sort and restores the query's normal order. Choosing a sort option never requests device location.

With this filter set to **Submit** and Geolocation set to **On submit**, a resolved pending location enables Distance before submission so visitors can apply both together. See [Distance sorting setup](https://academy.bricksbuilder.io/builder/dynamic-content/query-filters/#distance-sorting) for apply modes, URL behavior, and failed requests.

> **Developer reference**
>
> See the [Filter - Radio Schema](https://academy.bricksbuilder.io/developer/schema/elements/filter-radio/) for the full JSON schema of this element's settings and controls.

---

# Filter range

Source: https://academy.bricksbuilder.io/builder/elements/filter/filter-range/

*Filter query results by numeric ranges using sliders or input fields, with optional default minimum and maximum values.*

Creates a range slider or input interface for filtering content by numeric ranges. Perfect for price filtering, numeric custom fields, or any data that has minimum and maximum values. Supports both slider and input field display modes.

**Tip:** Essential for e-commerce price filtering or any scenario where users need to filter by numeric ranges.

## Settings

- **Target query** (query-list) - Select the Posts, Terms, or Users query this filter should target.
- **URL parameter** (text) - Define a unique, more readable URL parameter name for this filter.
- **Apply on** (select) - Choose when to apply the filter. Options: Input (immediate), Submit (requires button click). Default: Input.
- **Source** (select) - Data source for filter options. Currently limited to Custom field.
- **Field type** (select) - Type of field when using custom field source. Options: Post, Term, User.
- **Provider** (select) - Custom field provider for integration (ACF, Meta Box, etc.).
- **Meta key** (text) - Custom field key containing numeric values for range filtering.
- **Disable auto min/max value** (checkbox) - Manually set min/max values instead of auto-detecting from query results.
- **Mode** (select) - Display mode for the range filter. Options: Slider (visual slider), Input (text inputs).
- **Step** (number) - Increment step for range values. Default: 1.
- **Decimal places** (number) - Number of decimal places to display. Default: 0.
- **Thousand separator** (checkbox) - Add thousand separators to displayed values.
- **Separator** (text) - Thousand separator character. Default: ,.
- **Label** - Settings for range value labels.
  - **Min** (text) - Label for minimum value.
  - **Max** (text) - Label for maximum value.
  - **Direction** (direction) - Layout direction for min/max labels (row/column).
  - **Gap** (number) - Spacing between min/max labels.
- **Input** - Settings for input field mode.
  - **Placeholder** (text) - Placeholder text for input fields.
  - **Typography** (typography) - Typography for input field text.
- **Slider** - Settings for slider mode.
  - **Track color** (color) - Color of the slider track.
  - **Range color** (color) - Color of the selected range on the slider.
  - **Handle color** (color) - Color of the slider handles.
  - **Handle size** (number) - Size of the slider handles.
  - **Track height** (number) - Height of the slider track.
- **Active filter** - Settings for active filter display.
  - **Prefix** (text) - Text to display before filter value.
  - **Suffix** (text) - Text to display after filter value.
  - **Title** (text) - Custom title attribute for filter links.

## Default selection {#default-selection}

Starting with **Bricks 2.5**, this filter can apply a selection before the first query runs. Under **Default value**, enter numeric **Minimum** and **Maximum** values. Leave one endpoint empty to use the original range boundary. Defaults are limited to the original available range and support dynamic data.

The default applies even with **Apply on** set to **Submit**. Filter URL selections take precedence, and **Reset** clears the selection instead of restoring the default. A fresh visit or reload without filter parameters applies it again. See [default filter values](https://academy.bricksbuilder.io/builder/dynamic-content/query-filters/#default-values) for shared defaults, validation, and URL behavior.

> **Developer reference**
>
> See the [Filter - Range Schema](https://academy.bricksbuilder.io/developer/schema/elements/filter-range/) for the full JSON schema of this element's settings and controls.

---

# Filter search

Source: https://academy.bricksbuilder.io/builder/elements/filter/filter-search/

*Search query results without a page reload, configure initial search text, and choose AJAX or redirect behavior for Enter.*

Provides a live AJAX search input for real-time content filtering. Searches through post content, titles, and custom fields without page refresh. Features debouncing, minimum character requirements, and optional clear functionality.

**Tip:** Perfect for creating instant search experiences. Use the debounce setting to control API call frequency, and minimum characters to improve performance.

## Settings

- **Target query** (query-list) - Select the Posts, Terms, or Users query this filter should target.
- **URL parameter** (text) - Define a unique, more readable URL parameter name for this filter.
- **Apply on** (select) - Choose when to apply the filter. Options: Input (immediate), Submit (button click or Enter). Default: Input.
- **Debounce (ms)** (number) - Delay before triggering search after typing stops. Default: 500ms.
- **Min. characters** (number) - Minimum characters required to trigger search. Default: 3.
- **Enter action** (select, Bricks 2.4) - Choose **AJAX search** (default) or **Redirect to URL**. Requires a target query.
- **Trigger Filter Submit interactions** (checkbox, Bricks 2.4) - Run the target query's Filter Submit start/end interactions when Enter triggers an AJAX search. Disabled by default and available when Enter action is AJAX search.
- **Redirect to** (text, Bricks 2.4) - Destination URL when Enter action is Redirect to URL. Active filters for the same query are appended as URL parameters.
- **Open in new tab** (checkbox, Bricks 2.4) - Open the Enter-key redirect in a new tab. Available when a redirect URL is set.
- **Input** - Settings for the search input field.
  - **Placeholder** (text) - Placeholder text for the search input. Default: Search.
  - **Placeholder typography** (typography) - Typography for placeholder text.
  - **Label** (text) - Optional label text above the input field.
  - **Label typography** (typography) - Typography for the label text.
- **Icon (Clear)** - Settings for the clear/reset icon.
  - **Icon** (icon) - Icon to display for clearing the search.
  - **Icon color** (color) - Color of the clear icon.
  - **Icon size** (number) - Size of the clear icon.
- **Active filter** - Settings for active filter display.
  - **Prefix** (text) - Text to display before filter value.
  - **Suffix** (text) - Text to display after filter value.
  - **Title** (text) - Custom title attribute for filter links.

## Search with Enter

Pressing Enter runs the configured action immediately, including when **Apply on** is set to **Submit**. Enter bypasses the typing debounce and minimum character threshold.

For a search field that takes visitors to another results page, select a **Target query**, set **Enter action** to **Redirect to URL**, and enter the destination under **Redirect to**. Configure the destination's filters to recognize the same URL parameter names. Leave **Open in new tab** off to navigate in the current tab. An empty redirect URL falls back to an AJAX search.

For an AJAX search that should close an Offcanvas after submission, enable **Trigger Filter Submit interactions** and use the [Filter Submit interaction triggers](https://academy.bricksbuilder.io/builder/features/interactions/#filter-submit-triggers). Ordinary typing does not trigger these submit interactions. The redirect action does not run them.

## Default selection {#default-selection}

Starting with **Bricks 2.5**, this filter can apply a selection before the first query runs. Use **Default value** to set initial search text. The field supports dynamic data and treats commas as part of the search text.

The default applies even with **Apply on** set to **Submit**. Filter URL selections take precedence, and **Reset** clears the selection instead of restoring the default. A fresh visit or reload without filter parameters applies it again. See [default filter values](https://academy.bricksbuilder.io/builder/dynamic-content/query-filters/#default-values) for shared defaults, validation, and URL behavior.

> **Developer reference**
>
> See the [Filter - Search Schema](https://academy.bricksbuilder.io/developer/schema/elements/filter-search/) for the schema snapshot and Bricks 2.4 settings reference.
