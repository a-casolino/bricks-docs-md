# Text Decoration Control

Source: https://academy.bricksbuilder.io/developer/controls/text-decoration-control/

*Reference for the Bricks Text Decoration control, including its options, CSS mapping, and usage in custom elements.*

Use the **text-decoration** control to allow users to set the text-decoration CSS property like so:

```php
public function set_controls() {
  $this->controls['textDecoration'] = [ // Setting key
    'tab' => 'content',
    'label' => esc_html__( 'Text decoration', 'bricks' ),
    'type' => 'text-decoration',
    'css' => [
      [
        'property' => 'text-decoration',
        'selector' => '.text-wrapper',
      ],
    ],
  ];
}
```
