# Filter: bricks/woocommerce/predefined_elements/remote_payload

Source: https://academy.bricksbuilder.io/developer/hooks/filters/bricks-woocommerce-predefined_elements-remote_payload/

*Filters the remote WooCommerce predefined elements payload.*

Filters the remote WooCommerce predefined elements payload after Bricks decodes the response and before it validates/caches the payload.

## Parameters

- `$remote_payload` (array|mixed): Decoded remote payload data.

## Example usage

```php
add_filter( 'bricks/woocommerce/predefined_elements/remote_payload', function( $remote_payload ) {
    return $remote_payload;
} );
```
